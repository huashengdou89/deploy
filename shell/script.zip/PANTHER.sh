###############################################################################
# File Name: PANTHER.sh
# Author: shujun
# mail: shujun@hd123.com
# Created Time: Mon Aug 15 11:28:17 CST 2016
###############################################################################
#!/bin/bash
ACTION=${ACTION:-install}
IMAGE=${IMAGE:-panther-dts-server}
VERSION=${VERSION:-1.0}
DOCKERHUB=${DOCKERHUB:-harborka.qianfan123.com}
WEBPORT=${WEBPORT:-18180}
PANTHERSERVERHTTPSPORT=${PANTHERSERVERHTTPSPORT:-18143}
PANTHERJMXPORT=${PANTHERJMXPORT:-19148}
DEPLOYDIR=${DEPLOYDIR:-data}
LOGDIR=${LOGDIR:-/${DEPLOYDIR}/heading/${ENVNAME}/log_${ENVNAME}/${IMAGE}}
SHAREDIR=${SHAREDIR:-/${DEPLOYDIR}/heading/${ENVNAME}/panther-download}
EXTRANETHOST=${EXTRANETHOST:-192-168-251-5}
PROTOCOL=http
POSTPORT=${POSTPORT:-5435}
#POSTDBLINK=${POSTDBLINK:-172.17.14.1}
OLDORAURL=${OLDORAURL:-172.17.10.70:1521:popodb}
NEWORAURL=${NEWORAURL:-192.168.251.4:1521:hdappts}
NEWORAUSER=${NEWORAUSER:-hd40}
NEWORAPWD=${NEWORAPWD:-yfrp4vh0bpwg}
POSTUSER=${POSTUSER:-daor}
POSTPWD=${POSTPWD:-hd5432}
POSTDBNAME=${POSTDBNAME:-hdtest}
PGSQLDATADIR=${PGSQLDATADIR:-/${DEPLOYDIR}/heading/${ENVNAME}/pgsql_${ENVNAME}/data}


#选项后面的冒号表示该选项需要参数
ARGS=`getopt -o v: --long webport: -n 'PANTHER.sh' -- "$@"`
if [ $? != 0 ]; then
    echo "Terminating..."
    exit 1
fi

#echo $ARGS
#将规范化后的命令行参数分配至位置参数（$1,$2,...)
eval set -- "${ARGS}"

while true
do
    case "$1" in
		-v) 
		    VERSION="$2"; 
			shift 2 ;;
		--webport)
      		WEBPORT="$2"; 
			shift 2 
			;;
        --)
            shift
            break
            ;;
        *)
            echo "Internal error!"
            exit 1
            ;;
    esac
done

#处理剩余的参数
for arg in $@
do
    echo "processing $arg"
done

start_container() {

    ID=$(sudo docker run -d \
						 -p ${WEBPORT}:8080 \
						 -p ${PANTHERHTTPSPORT}:8443 \
						 -p ${PANTHERJMXPORT}:${PANTHERJMXPORT} \
						 -v ${LOGDIR}:/opt/heading/tomcat7/logs \
						 -v ${SHAREDIR}:/opt/heading/tomcat7/webapps/panther-dts-server/download \
						 -v /usr/share/zoneinfo/Asia/Shanghai:/etc/localtime \
						 --restart=on-failure:3 \
						 --log-opt max-size=50m \
						 -m 6g \
						 -e JAVA_OPTS="-server -Xms512m -Xmx3072m -XX:PermSize=256M -XX:MaxPermSize=512M -Duser.timezone=GMT+08 -Dfile.encoding=UTF-8 -Dcom.sun.management.jmxremote -Dcom.sun.management.jmxremote.port=${PANTHERJMXPORT} -Dcom.sun.management.jmxremote.rmi.port=${PANTHERJMXPORT} -Dcom.sun.management.jmxremote.authenticate=false -Dcom.sun.management.jmxremote.ssl=false -Dcom.sun.management.jmxremote.local.only=false -Djava.rmi.server.hostname=${INTRANETIP}" \
					     --name ${IMAGE}_${ENVNAME} ${DOCKERHUB}/dts-store/${IMAGE}:${VERSION}) >/dev/null 2>&1
}

start_pgsql() {

    ID=$(sudo docker run -d \
						 -v /usr/share/zoneinfo/Asia/Shanghai:/etc/localtime \
						 -e POSTGRES_DB=${POSTDBNAME} \
						 -e POSTGRES_USER=${POSTUSER} \
					     --restart=always \
						 -e POSTGRES_PASSWORD=${POSTPWD} \
						 -p ${POSTPORT}:5432 \
						 -v ${PGSQLDATADIR}:/var/lib/postgresql/data \
						 --name pgsql_${ENVNAME} ${DOCKERHUB}/component/postgres:alpine) >/dev/null 2>&1
}

deploying_container() {

    ID=$(sudo docker exec \
						-e CEXTRANETIP="${EXTRANETIP}" \
						-e COLDORAURL="${OLDORAURL}" \
						-e CNEWORAURL="${NEWORAURL}" \
						-e CNEWORAUSER="${NEWORAUSER}" \
						-e CNEWORAPWD="${NEWORAPWD}" \
						-e CPOSTUSER="${POSTUSER}" \
						-e CPOSTPWD="${POSTPWD}" \
						-e CPOSTPORT="${POSTPORT}" \
						-e CPOSTDBNAME="${POSTDBNAME}" \
						${IMAGE}_${ENVNAME} sh -c '
												sed -i "
													s%\r$%%;\
													s%${COLDORAURL}%${CNEWORAURL}%;\
													s%hd40%${CNEWORAUSER}%;\
													s%hd40_bjppmt%${CNEWORAPWD}%;\
													s%daor%${CPOSTUSER}%;\
													s%hd5432%${CPOSTPWD}%;\
													s%postgresql:\/\/172.17.14.1:5435\/hdtest%postgresql:\/\/${CEXTRANETIP}:${CPOSTPORT}\/${CPOSTDBNAME}%" /opt/heading/tomcat7/webapps/panther-dts-server/WEB-INF/classes/panther-dts-server.properties') >/dev/null 2>&1
}

cpout_config() {
    sudo docker cp ${IMAGE}_${ENVNAME}:/opt/heading/tomcat7/webapps/panther-dts-server/WEB-INF/classes/panther-dts-server.properties ${ConfPath}
}

cpin_config() {
    sudo docker cp ${ConfPath}/panther-dts-server.properties ${IMAGE}_${ENVNAME}:/opt/heading/tomcat7/webapps/panther-dts-server/WEB-INF/classes/
}

pull_image() {
    set +e
    echo "Waiting for pull ${IMAGE}"
	until
		(sudo docker login -u ${DOCKERHUBUSER} -p ${DOCKERHUBUSERPW} ${DOCKERHUB};
		 sudo docker pull ${DOCKERHUB}/dts-store/${IMAGE}:${VERSION} | sudo tee /tmp/${IMAGE}-${VERSION}_pull.log;
		);do
		printf '.'
		sleep 1
	done
}

export -f pull_image

if [ "${ACTION}" = "install" ]; then
	set -e
    get_ip
	get_exip
    pull_image
	image_exist
    pgsql_exist
	container_exist
	
	echo "Install and deploying ${IMAGE}"
    echo "## Install begins : ${IMAGE}"
    start_container
    if [ $? -ne 0 ]; then
		echo "Install failed..."
		exit 1
    fi
    echo "## Install ends   : ${IMAGE}"
	echo "## deploying begins : ${IMAGE}"
    deploying_container
    if [ $? -ne 0 ]; then
		echo "deploying failed..."
		exit 1
    fi
    echo "## deploying ends   : ${IMAGE}"
	
	sleep 10
	echo "Restart ${IMAGE}"
	restart_container
	sleep 30
    restart_container
	cpout_config
	
    echo "${IMAGE} available at ${PROTOCOL}://${INTRANETIP}:${WEBPORT}/${IMAGE} or ${PROTOCOL}://${EXTRANETIP}:${WEBPORT}/${IMAGE}"
    echo "Username: guest Password: guest"
	echo "Done."
elif [ "${ACTION}" = "redeploy" ]; then
	pro_redeploy
	echo "${IMAGE} available at ${PROTOCOL}://${INTRANETIP}:${WEBPORT}/${IMAGE} or ${PROTOCOL}://${EXTRANETIP}:${WEBPORT}/${IMAGE}"
    echo "Username: guest Password: guest"
	echo "Done."
else
    echo "Unknown action ${ACTION}"
    exit 1
fi 
