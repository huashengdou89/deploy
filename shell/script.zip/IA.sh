###############################################################################
# File Name: IA.sh
# Author: shujun
# mail: shujun@hd123.com
# Created Time: Mon Aug 15 11:28:17 CST 2016
###############################################################################
#!/bin/bash
ACTION=${ACTION:-install}
IMAGE=${IMAGE:-ia}
VERSION=${VERSION:-5.4.1}
DOCKERHUB=${DOCKERHUB:-dockerhub.hd123.com}
WEBPORT=${WEBPORT:-18581}
DEPLOYDIR=${DEPLOYDIR:-data}
LOGDIR=${LOGDIR:-/${DEPLOYDIR}/heading/${ENVNAME}/log_${ENVNAME}/${IMAGE}}
EXTRANETHOST=${EXTRANETHOST:-192-168-251-5}
PROTOCOL=http
IAOLDORAURL=${IAOLDORAURL:-192.192.192.192:1521:hdiaku}
IANEWORAURL=${IANEWORAURL:-192.168.251.4:1521:hdappts}
OLDORAURL=${OLDORAURL:-192.192.192.192:1521:h4ku}
NEWORAURL=${NEWORAURL:-192.168.251.4:1521:hdappts}
IAOLDORAPWD=${IAOLDORAPWD:-hdiamima}
IANEWORAPWD=${IANEWORAPWD:-yfrp4vh0bpwg}
OLDORAPWD=${OLDORAPWD:-hd40mima}
NEWORAPWD=${NEWORAPWD:-yfrp4vh0bpwg}
OLDLIC=${OLDLIC:-192.192.192.192}
NEWLIC=${NEWLIC:-192.168.251.8}

#选项后面的冒号表示该选项需要参数
ARGS=`getopt -o v: --long webport: -n 'IA.sh' -- "$@"`
if [ $? != 0 ]; then
    echo "Terminating..."
    exit 1
fi

#echo $ARGS
#将规范化后的命令行参数分配至位置参数（$1,$2,...)
eval set -- "${ARGS}"

while true
do
    case "$1" in
		-v) 
		    VERSION="$2"; 
			shift 2 ;;
		--webport)
      		WEBPORT="$2"; 
			shift 2 
			;;
        --)
            shift
            break
            ;;
        *)
            echo "Internal error!"
            exit 1
            ;;
    esac
done

#处理剩余的参数
for arg in $@
do
    echo "processing $arg"
done

start_container() {

    ID=$(sudo docker run -d \
						 -p ${WEBPORT}:8080 \
						 -v ${LOGDIR}:/opt/heading/tomcat7/logs \
						 -v /usr/share/zoneinfo/Asia/Shanghai:/etc/localtime \
						 --restart=on-failure:3 \
						 --log-opt max-size=50m \
						 -m 1g \
						 -e JAVA_OPTS="-server -Xms512m -Xmx1024m -XX:PermSize=256M -XX:MaxPermSize=512M -Duser.timezone=GMT+08 -Dfile.encoding=UTF-8 -Dcom.sun.management.jmxremote -Dcom.sun.management.jmxremote.port=9648 -Dcom.sun.management.jmxremote.rmi.port=9648 -Dcom.sun.management.jmxremote.authenticate=false -Dcom.sun.management.jmxremote.ssl=false -Dcom.sun.management.jmxremote.local.only=false -Djava.rmi.server.hostname=${INTRANETIP}" \
						 --name ${IMAGE}_${ENVNAME} ${DOCKERHUB}/${IMAGE}:${VERSION}) >/dev/null 2>&1
}

deploying_container() {

    ID=$(sudo docker exec \
						-e CEXTRANETIP="${EXTRANETIP}" \
						-e COLDORAURL="${OLDORAURL}" \
						-e CNEWORAURL="${NEWORAURL}" \
						-e CIAOLDORAURL="${IAOLDORAURL}" \
						-e CIANEWORAURL="${IANEWORAURL}" \
						-e CIAOLDORAPWD="${IAOLDORAPWD}" \
						-e CIANEWORAPWD="${IANEWORAPWD}" \
						-e COLDORAPWD="${OLDORAPWD}" \
						-e CNEWORAPWD="${NEWORAPWD}" \
						-e COLDLIC="${OLDLIC}" \
						-e CNEWLIC="${NEWLIC}" \
						-e CWEBPORT="${WEBPORT}" \
						-e CLDAPURL="${LDAPURL}" \
						${IMAGE}_${ENVNAME} sh -c '
												sed -i "
													s%\r$%%;\
													s%${COLDLIC}%${CNEWLIC}%;\
													s%${CIAOLDORAURL}%${CIANEWORAURL}%;\
													s%${CIAOLDORAPWD}%${CIANEWORAPWD}%" /opt/heading/tomcat7/webapps/ia-audit-server/WEB-INF/classes/ia-audit-server.properties && \
												sed -i "
													s%\r$%%;\
													s%${COLDLIC}%${CNEWLIC}%;\
													s%127.0.0.1:389%${CLDAPURL}%" /opt/heading/tomcat7/webapps/ia-authen-server/WEB-INF/classes/ia-authen-server.properties && \
												sed -i "
													s%\r$%%;\
													s%${COLDLIC}%${CNEWLIC}%;\
													s%${CIAOLDORAURL}%${CIANEWORAURL}%;\
													s%${CIAOLDORAPWD}%${CIANEWORAPWD}%" /opt/heading/tomcat7/webapps/ia-author-server/WEB-INF/classes/ia-author-server.properties && \
												sed -i "
													s%\r$%%;\
													s%${COLDLIC}%${CNEWLIC}%" /opt/heading/tomcat7/webapps/ia-cas-server/WEB-INF/cas.properties && \
												sed -i "
													s%\r$%%;\
													s%${COLDLIC}%${CNEWLIC}%;\
													s%${CIAOLDORAURL}%${CIANEWORAURL}%;\
													s%${CIAOLDORAPWD}%${CIANEWORAPWD}%;\
													s%123.123.123.123:8680%${CEXTRANETIP}:${CWEBPORT}%" /opt/heading/tomcat7/webapps/ia-web/WEB-INF/classes/ia-web.properties && \
												sed -i "
													s%\r$%%;\
													s%123.123.123.123:8680%${CEXTRANETIP}:${CWEBPORT}%" /opt/heading/tomcat7/webapps/ia-web/WEB-INF/classes/ia-web.xml && \
												sed -i "
													s%\r$%%;\
													s%123.123.123.123:8680%${CEXTRANETIP}:${CWEBPORT}%" /opt/heading/tomcat7/webapps/hdframesvc/WEB-INF/web.xml && \
												sed -i "
													s%\r$%%;\
													s%{COLDORAURL}%${CNEWORAURL}%;\
													s%${COLDORAPWD}%${CNEWORAPWD}%;\
													s%123.123.123.123:8680%${CEXTRANETIP}:${CWEBPORT}%" /opt/heading/tomcat7/webapps/hdframesvc/WEB-INF/classes/hdframe-server.properties') >/dev/null 2>&1
}

cpout_config() {
    sudo docker cp ${IMAGE}_${ENVNAME}:/opt/heading/tomcat7/webapps/ia-audit-server/WEB-INF/classes/ia-audit-server.properties ${ConfPath}
	sudo docker cp ${IMAGE}_${ENVNAME}:/opt/heading/tomcat7/webapps/ia-authen-server/WEB-INF/classes/ia-authen-server.properties ${ConfPath}
	sudo docker cp ${IMAGE}_${ENVNAME}:/opt/heading/tomcat7/webapps/hdframesvc/WEB-INF/classes/hdframe-server.properties ${ConfPath}
	sudo docker cp ${IMAGE}_${ENVNAME}:/opt/heading/tomcat7/webapps/hdframesvc/WEB-INF/web.xml ${ConfPath}
	sudo docker cp ${IMAGE}_${ENVNAME}:/opt/heading/tomcat7/webapps/ia-web/WEB-INF/classes/ia-web.xml ${ConfPath}
	sudo docker cp ${IMAGE}_${ENVNAME}:/opt/heading/tomcat7/webapps/ia-web/WEB-INF/classes/ia-web.properties ${ConfPath}
	sudo docker cp ${IMAGE}_${ENVNAME}:/opt/heading/tomcat7/webapps/ia-cas-server/WEB-INF/cas.properties ${ConfPath}
	sudo docker cp ${IMAGE}_${ENVNAME}:/opt/heading/tomcat7/webapps/ia-author-server/WEB-INF/classes/ia-author-server.properties ${ConfPath}
}

cpin_config() {
	sudo docker cp ${ConfPath}/ia-audit-server.properties ${IMAGE}_${ENVNAME}:/opt/heading/tomcat7/webapps/ia-audit-server/WEB-INF/classes/
	sudo docker cp ${ConfPath}/ia-authen-server.properties ${IMAGE}_${ENVNAME}:/opt/heading/tomcat7/webapps/ia-authen-server/WEB-INF/classes/
	sudo docker cp ${ConfPath}/hdframe-server.properties ${IMAGE}_${ENVNAME}:/opt/heading/tomcat7/webapps/hdframesvc/WEB-INF/classes/
	sudo docker cp ${ConfPath}/web.xml ${IMAGE}_${ENVNAME}:/opt/heading/tomcat7/webapps/hdframesvc/WEB-INF/
	sudo docker cp ${ConfPath}/ia-web.xml ${IMAGE}_${ENVNAME}:/opt/heading/tomcat7/webapps/ia-web/WEB-INF/classes/
	sudo docker cp ${ConfPath}/ia-web.properties ${IMAGE}_${ENVNAME}:/opt/heading/tomcat7/webapps/ia-web/WEB-INF/classes/
	sudo docker cp ${ConfPath}/cas.properties ${IMAGE}_${ENVNAME}:/opt/heading/tomcat7/webapps/ia-cas-server/WEB-INF/
	sudo docker cp ${ConfPath}/ia-author-server.properties ${IMAGE}_${ENVNAME}:/opt/heading/tomcat7/webapps/ia-author-server/WEB-INF/classes/
}

if [ "${ACTION}" = "install" ]; then
	pro_install
    echo "${IMAGE} available at ${PROTOCOL}://${INTRANETIP}:${WEBPORT}/${IMAGE}-web or ${PROTOCOL}://${EXTRANETIP}:${WEBPORT}/${IMAGE}-web"
	echo "Done."
elif [ "${ACTION}" = "redeploy" ]; then
	pro_redeploy
    echo "${IMAGE} available at ${PROTOCOL}://${INTRANETIP}:${WEBPORT}/${IMAGE}-web or ${PROTOCOL}://${EXTRANETIP}:${WEBPORT}/${IMAGE}-web"
	echo "Done."
else
    echo "Unknown action ${ACTION}"
    exit 1
fi
