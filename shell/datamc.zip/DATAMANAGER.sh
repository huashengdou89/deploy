###############################################################################
# File Name: DATAMANAGER.sh
# Author: shujun
# mail: shujun@hd123.com
# Created Time: Mon Aug 15 11:28:17 CST 2016
###############################################################################
#!/bin/bash
ACTION=${ACTION:-install}
IMAGE=${IMAGE:-datamanager-web}
VERSION=${VERSION:-latest}
MONGOVERSION=${MONGOVERSION:-3.6}
DOCKERHUB=${DOCKERHUB:-harborka.qianfan123.com}
WEBPORT=${WEBPORT:-8280}
DEPLOYDIR=${DEPLOYDIR:-data}
LOGDIR=${LOGDIR:-/${DEPLOYDIR}/heading/${ENVNAME}/log_${ENVNAME}/${IMAGE}}
PROTOCOL=http
MONGOPORT=${MONGOPORT:-27017}
MONGODATADIR=${MONGODATADIR:-/${DEPLOYDIR}/heading/${ENVNAME}/datamanager_mongo_${ENVNAME}/data}
ORAURL=${ORAURL:-172.17.11.84:1521:db2}
ORAUSER=${ORAUSER:-hd40}
ORAPWD=${ORAPWD:-hd40}


#选项后面的冒号表示该选项需要参数
ARGS=`getopt -o v: --long webport: -n 'DATAMANAGER.sh' -- "$@"`
if [ $? != 0 ]; then
    echo "Terminating..."
    exit 1
fi

#echo $ARGS
#将规范化后的命令行参数分配至位置参数（$1,$2,...)
eval set -- "${ARGS}"

while true
do
    case "$1" in
		-v) 
		    VERSION="$2"; 
			shift 2 ;;
		--webport)
      		WEBPORT="$2"; 
			shift 2 
			;;
        --)
            shift
            break
            ;;
        *)
            echo "Internal error!"
            exit 1
            ;;
    esac
done

#处理剩余的参数
for arg in $@
do
    echo "processing $arg"
done

start_container() {

    ID=$(sudo docker run -d \
						 -p ${WEBPORT}:8080 \
						 --name datamanager-web_${ENVNAME} \
						 -v ${LOGDIR}:/opt/heading/tomcat/logs \
						 -v /usr/share/zoneinfo/Asia/Shanghai:/etc/localtime \
						 --restart=on-failure:3 \
						 --log-opt max-size=50m \
						 -m 2g \
						 ${DOCKERHUB}/component/${IMAGE}:${VERSION} \
						 all \
						 --server.port=8080 \
						 --server.context-path=/datamanager-web \
						 --endpoints.sensitive=false \
						 --logging.level.root=INFO \
						 --logging.file=/opt/heading/tomcat/logs/datamanager.log \
						 --server.tomcat.basedir=/opt/heading/tomcat \
						 --server.tomcat.accesslog.enabled=true \
						 --server.tomcat.accesslog.pattern=%t %a %U %s %D %b %{User-Agent}i \
						 --server.tomcat.accesslog.prefix=localhost_access_log \
						 --server.tomcat.accesslog.suffix=.txt \
						 --logging.level.druid.sql.Statement=debug \
						 --spring.datasource.platform=oracle \
						 --spring.datasource.driver-class-name=oracle.jdbc.driver.OracleDriver \
						 --spring.datasource.url=jdbc:oracle:thin:@${ORAURL} \
						 --spring.datasource.username=${ORAUSER} \
						 --spring.datasource.password=${ORAPWD} \
						 --spring.datasource.tomcat.max-wait=10000 \
						 --spring.datasource.tomcat.max-active=300 \
						 --spring.datasource.tomcat.test-on-borrow=true \
						 --spring.datasource.tomcat.initial-size=20 \
						 --spring.jpa.hibernate.ddl-auto=none \
						 --spring.jpa.show-sql=true \
						 --spring.jackson.serialization.indent_output=true \
						 --spring.jpa.hibernate.naming.physical-strategy=org.hibernate.boot.model.naming.PhysicalNamingStrategyStandardImpl \
						 --spring.data.mongodb.uri=mongodb://${INTRANETIP}:${MONGOPORT}/datamanager) >/dev/null 2>&1
}

start_mongo() {

    ID=$(sudo docker run -d \
						 -p ${MONGOPORT}:27017 \
						 -v ${MONGODATADIR}:/data/db \
						 --name mongo_${ENVNAME} ${DOCKERHUB}/component/mongo:${MONGOVERSION}) >/dev/null 2>&1
}

pull_image() {
    set +e
    echo "Waiting for pull ${IMAGE}"
	until
		(sudo docker login -u ${DOCKERHUBUSER} -p ${DOCKERHUBUSERPW} ${DOCKERHUB};
		 sudo docker pull ${DOCKERHUB}/component/${IMAGE}:${VERSION} | sudo tee /tmp/${IMAGE}-${VERSION}_pull.log;
		);do
		printf '.'
		sleep 1
	done
}

export -f pull_image

if [ "${ACTION}" = "install" ]; then
    pro_install
    echo "${IMAGE} available at ${PROTOCOL}://${INTRANETIP}:${WEBPORT}/${IMAGE}/swagger-ui.html or ${PROTOCOL}://${EXTRANETIP}:${WEBPORT}/${IMAGE}/swagger-ui.html"
	echo "Done."
else
    echo "Unknown action ${ACTION}"
    exit 1
fi
