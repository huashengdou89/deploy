Ext.define('Cxt.loader.Login', {
			extend : 'Ext.container.Viewport',
			requires : ['Cxt.widgets.HtmlLayout'],
			mixins:['Cxt.I18n'],
			initComponent : function() {
				var me = this, username, password, cfg;
				if (appcfg.demo) {
					username = appcfg.demo.username;
					password = appcfg.demo.password;
				}
				cfg = {
					layout : {
						type : 'html',
						url : appcfg.login.html
					},
					items : [{
								itemId : 'form',
								xtype : 'form',
								title : me.itext('登录'),
								bodyPadding : 10,
								defaults : {
									labelWidth : me.itext('字段宽度', 50)
								},
								items : [{
											itemId : 'username',
											xtype : 'textfield',
											fieldLabel : me.itext('用户名'),
											name : 'username',
											value: username
										}, {
											itemId : 'password',
											xtype : 'textfield',
											inputType : 'password',
											fieldLabel : me.itext('口令'),
											name : 'password',
											value: password
										}],
								buttons : [{
											itemId : 'msg',
											xtype : 'label',
											style : {
												color : 'red'
											},
											flex : 1
										}, {
											itemId : 'loginButton',
											text : me.itext('登录'),
											handler : Ext.bind(me.onLogin, me)
										}]
							}]
				};
				Ext.apply(me, cfg);
				me.callParent();
			},

			onLogin : function() {
				var me = this;
				var mask = new Ext.LoadMask(Ext.getBody(), {
							msg : me.itext('正在登录...')
						});
				mask.show();
				Ext.Ajax.request({
							url : serviceUrl(appcfg.login.services.login),
							params : me.down('#form').getForm().getValues(),
							success : function(rsp) {
								mask.hide();
								var ret = Ext.JSON.decode(rsp.responseText);
								if (ret.success) {
									location.reload();
								} else {
									me.down('#msg').setText(ret.message);
								}
							}
						});
			}
		});
