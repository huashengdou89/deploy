/**
 * 在codenamefield中输入minChars(默认4)个字符,queryDelay(默认500)毫秒后会向svc发出GET请求.
 * 附加参数为query=输入的字符串&start=xxx&limit=xxx(由pageSize设置,默认20).
 * 期望的返回值是{success:true,data:[{id,code,name}]}
 */
Ext.define('Cxt.demo.widgets.CodeNameField', {
			extend : 'Ext.form.Panel',
			requires : ['Cxt.widgets.CodeNameField'],
			bodyPadding : 10,
			items : [{
						xtype : 'label',
						text : 'Need a php server'
					}, {
						xtype : 'codenamefield',
						fieldLabel : 'Code And Name',
						name : 'cn1',
						svc : serviceUrl('CodeNameSearch.php?table=cn1'),
						hideTrigger : false,
						width : 450,
						minChars : 2
					}]
		});