<?php
$cmd = $_GET["cmd"];
$id = $_GET["id"];

$sample = array(
	array(id=>"1",code=>"1",name=>"中国",parent=>null),
	array(id=>"2",code=>"2",name=>"美国",parent=>null),
	array(id=>"11",code=>"11",name=>"辽宁",parent=>"1"),
  array(id=>"111",code=>"111",name=>"大连",parent=>"11"),
  array(id=>"112",code=>"112",name=>"沈阳",parent=>"11"),
  array(id=>"12",code=>"12",name=>"江苏",parent=>"1"),
  array(id=>"121",code=>"121",name=>"苏州",parent=>"12"),
  array(id=>"122",code=>"122",name=>"无锡",parent=>"12"),
  array(id=>"21",code=>"21",name=>"加利福尼亚",parent=>"2"),
  array(id=>"22",code=>"22",name=>"新奥尔良",parent=>"2"),
  array(id=>"13",code=>"13",name=>"黑龙江",parent=>"1"),
  array(id=>"14",code=>"14",name=>"吉林",parent=>"1"),
  array(id=>"15",code=>"15",name=>"内蒙古",parent=>"1"),
  array(id=>"16",code=>"16",name=>"山东",parent=>"1"),
  array(id=>"17",code=>"17",name=>"河北",parent=>"1"),
  array(id=>"18",code=>"18",name=>"河南",parent=>"1"),
  array(id=>"19",code=>"19",name=>"山西",parent=>"1"),
  array(id=>"20",code=>"20",name=>"湖北",parent=>"1"),
  array(id=>"21",code=>"21",name=>"湖南",parent=>"1"),
  array(id=>"22",code=>"22",name=>"安徽",parent=>"1"),
  array(id=>"23",code=>"23",name=>"浙江",parent=>"1"),
  array(id=>"24",code=>"24",name=>"四川",parent=>"1")
);

echo "{success:true, data:[";

if ($cmd=="getChildren") {
	if (empty($id)) {
		$sep="";
		foreach ($sample as $val) {
			if (empty($val["parent"])) {
				echo $sep;
				$sep=",";
				echo json_encode($val);
			}
		}
	}
	else {
		$sep="";
		foreach ($sample as $val) {
			if ($id==$val["parent"]) {
				echo $sep;
				$sep=",";
				echo json_encode($val);
			}
		}
	}
} else if ($cmd=="getPath") {
	$data=array();
	while (!empty($id)) {
		$row=null;
		foreach ($sample as $val) {
			if ($id==$val["id"]){
				$row=$val;
				break;
			}
		}
		array_push($data, $row);
		$id=$row["parent"];
	}
	$sep="";
	for ($i=count($data)-1;$i>=0;--$i) { 
		echo $sep;
		$sep=",";
		echo json_encode($data[$i]);
	}
}

echo "]}"

?>