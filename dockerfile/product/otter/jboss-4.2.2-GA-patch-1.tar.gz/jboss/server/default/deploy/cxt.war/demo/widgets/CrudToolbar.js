/**
 * CrudToolbar的enableButtons(cmd,rec)会根据cmd和rec来设置按钮可用否. cmd取值edit或view.
 * 当cmd取值view时, 如果rec为空, 编辑和删除按钮无效.
 */
Ext.define('Cxt.demo.widgets.CrudToolbar', {
			extend : 'Ext.form.Panel',
			requires : ['Cxt.widgets.CrudToolbar'],
			layout : 'form',
			bodyPadding : 10,
			tbar : {
				itemId : 'toolbar',
				xtype : 'crudtoolbar'
			},
			initComponent : function() {
				var me = this;
				me.callParent();

				var tb = this.down('#toolbar');
				tb.on('addPressed', function() {
							delete me.rec;
							tb.enableButtons('edit');
						});
				tb.on('editPressed', function() {
							tb.enableButtons('edit');
						});
				tb.on('savePressed', function() {
							me.rec = {
								fidle : 'value'
							};
							tb.enableButtons('view', me.rec);
						});
				tb.on('cancelPressed', function() {
							tb.enableButtons('view', me.rec);
						});
				tb.on('deletePressed', function() {
							delete me.rec;
							tb.enableButtons('view', me.rec);
						});
			}
		});