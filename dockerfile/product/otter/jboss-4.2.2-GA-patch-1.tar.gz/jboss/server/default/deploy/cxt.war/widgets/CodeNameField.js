/**
 * 代码名称的输入域, 带有live search的功能.
 * <p>
 * 用法: {xtype:'codenamefiled', svc: 'someurl'}
 * <p>
 * svc用作获取数据, 详见下面的关于svc的说明.
 */
Ext.define('Cxt.widgets.CodeNameField', {
			extend : 'Ext.form.field.ComboBox',
			alias : 'widget.codenamefield',
			mixins : ['Cxt.I18n'],
			displayField : 'name',
			valueField : 'id',
			hideTrigger : true,
			listConfig : {
				getInnerTpl : function() {
					return '{code}-{name}';
				}
			},
			pageSize : 20,

			/**
			 * @cfg {string} svc 用作live search. 是store的url.
			 *      <p>
			 *      svc?query=输入的内容&limit=xxx&start=xxx
			 *      <p>
			 *      返回{data:[{id,code,name}]}
			 */

			initComponent : function() {
				var me = this;
				me.store = Ext.create('Ext.data.Store', {
							fields : ['id', 'code', 'name'],
							proxy : {
								type : 'ajax',
								url : me.svc,
								reader : {
									type : 'json',
									root : 'data'
								}
							},
							pageSize : me.pageSize
						});
				me.callParent();
			},
			validator : function() {
				var v = this.getValue();
				if (v == null || v != this.getRawValue())
					// 当没有任何内容输入时, v==null
					// 如果有输入的内容,但不是从列表中选择的,v==rawValue
					// 如果有输入的内容,并且是从列表中选择的,v是id值,rawValue是name值.这里认为这两个一定不会相同.
					return true;
				else
					return me.itext('记录不存在');
			}
		});