var DATEFORMAT = 'Y-m-d H:i:s';
var appcfg = {};
function serviceUrl(requestPath) {
	return appcfg.servicePath + requestPath;
}

Ext.Loader.setConfig({
			enabled : true
		});

Ext.onReady(init);

function runScript(url) {
	Ext.Ajax.request({
				url : url,
				async : false,
				success : function(rsp) {
					eval(rsp.responseText);
				}
			});
}

function init() {
	Ext.syncRequire(['Ext.LoadMask', 'Ext.util.Format', 'Ext.util.Cookies',
			'Ext.JSON', 'Ext.Ajax']);

	var iframes = document.getElementsByTagName('iframe');
	if (iframes && iframes.length > 0)
		document.body.removeChild(iframes[0]);

	// var dom = Ext.getBody().dom;
	// while (dom.firstChild)
	// dom.removeChild(dom.firstChild);

	Ext.getBody().mask('程序初始化...');

	Ext.util.Format.defaultDateFormat = DATEFORMAT;
	Ext.JSON.encodeDate = function(d) {
		return Ext.Date.format(d, '"' + DATEFORMAT + '"');
	};

	// appcfg
	Ext.Ajax.request({
				url : typeof(appCfgUrl) == 'undefined'
						? 'appcfg.json'
						: appCfgUrl,
				async : false,
				success : function(rsp) {
					Ext.apply(appcfg, Ext.JSON.decode(rsp.responseText));
					var value = Ext.util.Cookies.get('appcfg.desktop.view');
					if (value)
						appcfg.desktop.view = value;
					var value = Ext.util.Cookies.get('appcfg.locale');
					if (value)
						appcfg.locale = value;
					else
						delete appcfg.locale;
				}
			});

	// paths
	for (var name in appcfg.paths) {
		Ext.Loader.setPath(name, appcfg.paths[name]);
	}

	// override
	runScript(Ext.Loader.getPath('Cxt') + '/ext-override.js');

	// i18n
	if (appcfg.locale) {
		for (var name in appcfg.paths) {
			if (name == 'Ext')
				continue;
			try {
				var url = appcfg.paths[name] + '/locale/' + appcfg.locale
						+ '.json';
				Ext.Ajax.request({
							url : url,
							async : false,
							success : function(rsp) {
								try {
									var ret = Ext.JSON.decode(rsp.responseText);
									for (var c in ret) {
										Ext.syncRequire(c);
										var cls = Ext.ClassManager.get(c);
										var values = ret[c];
										if (values.statics)
											Ext.apply(cls, {
														i18n : values.statics
													});
										else
											Ext.override(cls, {
														i18n : values
													});
									}
								} catch (e) {
								}
							}
						});
			} catch (e) {
			}
		}
		runScript(Ext.Loader.getPath('Ext') + '/locale/ext-lang-'
				+ appcfg.locale + '.js');
	} else {
		runScript(Ext.Loader.getPath('Ext') + '/locale/ext-lang-zh_CN.js');
	}

	// usermenu
	Ext.Ajax.request({
				url : serviceUrl(appcfg.desktop.services.userMenu),
				params : {
					locale : appcfg.locale
				},
				success : function(rsp) {
					Ext.getBody().unmask();
					var ret = Ext.JSON.decode(rsp.responseText);
					if (ret.success) {
						appcfg.user = ret.data.user;
						appcfg.menu = ret.data.menu;
						appcfg.tagData = ret.data.tagData;
						var desktop = Ext.create(appcfg.desktop.view);
						if (appcfg.initView) {
							desktop.setContentPane(appcfg.initView);
						}
					} else {
						Ext.create(appcfg.login.view);
					}
				}
			});
}
