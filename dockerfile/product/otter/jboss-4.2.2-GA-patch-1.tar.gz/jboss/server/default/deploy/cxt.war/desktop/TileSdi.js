Ext.define('Cxt.desktop.TileSdi', {
	extend : 'Ext.container.Viewport',
	mixins : ['Cxt.I18n', 'Cxt.desktop.NavMgr'],
	requires : ['Cxt.Utils', 'Cxt.desktop.TopBanner', 'Cxt.desktop.FootBanner'],
	initComponent : function() {
		var me = this;
		var cfg = {
			layout : 'border',
			padding : 2,
			items : [{
						region : 'north',
						xtype : 'desktoptopbanner'
					}, {
						xtype : 'panel',
						region : 'center',
						layout : 'border',
						items : [{
									itemId : 'path',
									region : 'north',
									xtype : 'panel',
									border : 0,
									layout : {
										type : 'hbox',
										defaultMargins : 5
									}
								}, {
									itemId : 'contentPane',
									region : 'center',
									xtype : 'panel',
									layout : 'fit',
									border : 0
								}]
					}, {
						region : 'south',
						xtype : 'desktopfootbanner'
					}]
		};
		Ext.apply(me, cfg);
		me.callParent();

		var mi = appcfg.menu;
		mi.text = me.itext('主菜单');
		me.setPath([new Cxt.desktop.TileSdiMenuItemModel(mi)]);
	},

	showMenu : function() {
		var me = this;
		var view = Ext.create('Cxt.desktop.TileSdiMenuPanel', {
					cxtDesktop : me
				});
		return this.setContentView(view);
	},

	showView : function(record) {
		var viewClassName = record.get('view');
		if (!viewClassName)
			return;
		var view = Ext.create(viewClassName);
		return this.setContentView(view);
	},

	setContentView : function(view) {
		var me = this;
		var holder = me.down('#contentPane');
		if (!me.canLeaveChild(holder))
			return;
		holder.removeAll();
		holder.add(view);
		me.logEnter(view.$className);
		return view;
	},

	/** loader initView will call this */
	setContentPane : function(viewClassName) {
		var me = this;
		var mi = appcfg.menu;
		mi.text = me.itext('主菜单');
		var rec = new Cxt.desktop.TileSdiMenuItemModel(mi);
		var path = me.getPathFor(rec, viewClassName, []);
		me.setPath(path);
	},

	/** private */
	getPathFor : function(parent, viewClassName, path) {
		var me = this;
		var np = [].concat(path);
		np.push(parent);
		for (var i in parent.get('children')) {
			var c = parent.get('children')[i];
			rec = new Cxt.desktop.TileSdiMenuItemModel(c);
			if (c.view == viewClassName) {
				np.push(rec);
				return np;
			} else {
				var p = me.getPathFor(rec, viewClassName, np);
				if (p)
					return p;
			}
		}
		return null;
	},

	setPath : function(path) {
		var me = this;

		var rec = path[path.length - 1];
		if (rec.get('leaf')) {
			if (!me.showView(rec))
				return;
		} else {
			var menu = me.showMenu();
			if (!menu)
				return;
			menu.down('#menuitem').store.loadData(path[path.length - 1]
					.get('children'));
		}

		// path
		var display = me.down('#path');
		display.suspendLayouts();
		display.removeAll();
		for (var i = 0; i < path.length; ++i) {
			display.add({
						xtype : 'button',
						text : path[i].get('text'),
						height : 30,
						path : path.slice(0, i + 1),
						handler : function() {
							me.setPath(this.path);
						}
					});
		}
		display.resumeLayouts(true);

		me.path = path;
	},

	addPath : function(rec) {
		var me = this;
		var path = [].concat([], me.path);
		path.push(rec);
		me.setPath(path);
	}
});

Ext.define('Cxt.desktop.TileSdiMenuItemModel', {
			extend : 'Ext.data.Model',
			fields : ['text', 'view', 'children', 'leaf', 'id']
		});

Ext.define('Cxt.desktop.TileSdiMenuPanel', {
	extend : 'Ext.panel.Panel',
	initComponent : function() {
		var me = this;
		var cfg = {
			bodyPadding : 10,
			overflowY : 'auto',
			border : 0,
			items : [{
				itemId : 'menuitem',
				xtype : 'dataview',
				cls : 'tilemenuitem-selector',
				tpl : [
						'<tpl for=".">',
						' <div class="tilemenuitem">',
						'<table><tbody><tr><td>{text}</td></tr></tbody></table>',
						'</div>', '</tpl>'],
				itemSelector : 'div.tilemenuitem',
				trackOver : true,
				overItemCls : 'tilemenuitem-over',
				store : Ext.create('Ext.data.Store', {
							model : 'Cxt.desktop.TileSdiMenuItemModel',
							data : appcfg.menu
						}),
				listeners : {
					itemclick : function(dv, rec, item, index, e) {
						me.cxtDesktop.addPath(rec);
					}
				}
			}]
		};
		Ext.apply(me, cfg);
		me.callParent();
	}
});