Ext.onReady(function() {
	var cm = Ext.ClassManager, exists = Ext.Function.bind(cm.get, cm), parseCodes;

	if (Ext.Updater) {
		Ext.Updater.defaults.indicatorText = '<div class="loading-indicator">加载中...</div>';
	}

	/** 可加载中文名称的文件: encodeURI(url) */
	/*
	Ext.syncRequire('Ext.Loader');
	var extLoaderLoadScriptFile = Ext.Loader.loadScriptFile;
	Ext.Loader.loadScriptFile = function(url, onLoad, onError, scope,
			synchronous) {
		return extLoaderLoadScriptFile(encodeURI(url), onLoad, onError, scope,
				synchronous);
	};
	*/

	/** 可加载中文名称的URL: encodeURI(requestOptions.url) */
	/*
	Ext.define('Ext.cxt.data.Connection', {
				override : 'Ext.data.Connection',
				openRequest : function(options, requestOptions, async,
						username, password) {

					requestOptions.url = encodeURI(requestOptions.url);

					var xhr = this.newRequest(options);

					if (username) {
						xhr.open(requestOptions.method, requestOptions.url,
								async, username, password);
					} else {
						xhr.open(requestOptions.method, requestOptions.url,
								async);
					}

					if (options.withCredentials || this.withCredentials) {
						xhr.withCredentials = true;
					}

					return xhr;
				}
			});
	*/

	/**
	 * checkbox tree 3态, $treePrefix-checkbox-indeterminate
	 * nodeRec.set('checked', 'indeterminate')
	 */
	Ext.define("Ext.cxt.tree.Column", {
		override : "Ext.tree.Column",
		treeRenderer : function(value, metaData, record, rowIdx, colIdx, store,
				view) {
			var me = this, buf = [], format = Ext.String.format, depth = record
					.getDepth(), treePrefix = me.treePrefix, elbowPrefix = me.elbowPrefix, expanderCls = me.expanderCls, imgText = me.imgText, checkboxText = me.checkboxText, formattedValue = me.origRenderer
					.apply(me.origScope, arguments), blank = Ext.BLANK_IMAGE_URL, href = record
					.get('href'), target = record.get('hrefTarget'), cls = record
					.get('cls');

			while (record) {
				if (!record.isRoot() || (record.isRoot() && view.rootVisible)) {
					if (record.getDepth() === depth) {
						buf.unshift(format(imgText, treePrefix
										+ 'icon '
										+ treePrefix
										+ 'icon'
										+ (record.get('icon')
												? '-inline '
												: (record.isLeaf()
														? '-leaf '
														: '-parent '))
										+ (record.get('iconCls') || ''), record
										.get('icon')
										|| blank));
						if (record.get('checked') !== null) {
							var arg0 = treePrefix + 'checkbox', arg1 = '';
							if (record.get('checked')) {
								var cbcls = ' ' + treePrefix + 'checkbox-';
								if ('indeterminate' == record.get('checked')) {
									cbcls += 'indeterminate';
								} else {
									cbcls += 'checked';
								}
								arg0 += cbcls;
								arg1 = 'aria-checked="true"';
								metaData.tdCls += cbcls;
							}
							buf.unshift(format(checkboxText, arg0, arg1));
						}
						if (record.isLast()) {
							if (record.isExpandable()) {
								buf.unshift(format(imgText, (elbowPrefix
												+ 'end-plus ' + expanderCls),
										blank));
							} else {
								buf.unshift(format(imgText,
										(elbowPrefix + 'end'), blank));
							}

						} else {
							if (record.isExpandable()) {
								buf
										.unshift(format(
												imgText,
												(elbowPrefix + 'plus ' + expanderCls),
												blank));
							} else {
								buf.unshift(format(imgText,
										(treePrefix + 'elbow'), blank));
							}
						}
					} else {
						if (record.isLast() || record.getDepth() === 0) {
							buf.unshift(format(imgText,
									(elbowPrefix + 'empty'), blank));
						} else if (record.getDepth() !== 0) {
							buf.unshift(format(imgText, (elbowPrefix + 'line'),
									blank));
						}
					}
				}
				record = record.parentNode;
			}
			if (href) {
				buf.push('<a href="', href, '" target="', target, '">',
						formattedValue, '</a>');
			} else {
				buf.push(formattedValue);
			}
			if (cls) {
				metaData.tdCls += ' ' + cls;
			}
			return buf.join('');
		}
	});

	/** checkbox tree 3态, $treePrefix-checkbox-indeterminate */
	Ext.define('Ext.cxt.tree.View', {
				override : 'Ext.tree.View',
				onCheckChange : function(record) {
					var checked = record.get('checked');
					if (Ext.isBoolean(checked) || 'indeterminate' == checked) {
						if (Ext.isBoolean(checked))
							checked = !checked;
						else
							checked = false;
						record.set('checked', checked);
						this.fireEvent('checkchange', record, checked);
					}
				}
			});
});