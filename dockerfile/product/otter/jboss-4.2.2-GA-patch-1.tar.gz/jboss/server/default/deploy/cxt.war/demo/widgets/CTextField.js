/**
 * 当ctextfield失去焦点的时候, 如果文本框的内容和上次失去焦点时的不一样, 调用blurHandler
 */
Ext.define('Cxt.demo.widgets.CTextField', {
			extend : 'Ext.form.Panel',
			requires : ['Cxt.widgets.CTextField'],
			bodyPadding: 10,
			fieldDefaults: {
				labelWidth: 60
			},
			initComponent : function() {
				var me = this;
				me.items = [{
							xtype : 'ctextfield',
							name : 'field1',
							fieldLabel : 'field 1',
							blurHandler : function() {
								me.down('#msg')
										.setValue('field 1 content changed');
							}
						}, {
							xtype : 'ctextfield',
							name : 'field2',
							fieldLabel : 'field 2',
							blurHandler : function() {
								me.down('#msg')
										.setValue('field 2 content changed');
							}
						}, {
							itemId : 'msg',
							xtype : 'displayfield',
							value: 'message goes here'
						}];
				me.callParent();
			}
		});