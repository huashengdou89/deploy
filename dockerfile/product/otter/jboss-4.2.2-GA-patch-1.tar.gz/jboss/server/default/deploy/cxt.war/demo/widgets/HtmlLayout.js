/**
 * 使用外部提供的html文件进行格式编排
 */
Ext.define('Cxt.demo.widgets.HtmlLayout', {
			extend : 'Ext.form.Panel',
			requires : ['Cxt.widgets.HtmlLayout'],
			height : 120, // 这个一定要设置

			initComponent : function() {
				var me = this;
				me.layout = {
					type : 'html',
					url : serviceUrl('HtmlLayout.html')
				};
				me.items = [{
							itemId : 'p1',// 将被放置在html中id="p1"的容器中
							xtype : 'textfield',
							name : 'p1'
						}, {
							itemId : 'p2',
							xtype : 'textfield',
							name : 'p2'
						}];
				me.callParent();
			}
		});

// HtmlLayout.html:
// <table style="margin:10px;">
// <tbody>
// <tr>
// <td style="padding:5px">p1</td>
// <td style="padding:5px"><div id="p1"></div></td>
// </tr>
// <tr>
// <td style="padding:5px">p2</td>
// <td style="padding:5px"><div id="p2"></div></td>
// </tr>
// </tbody>
// </table>
