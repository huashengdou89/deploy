<?php
session_start();
if (isset($_SESSION['user'])) {
	$data = array(
		"success"=>true,
		"data"=>array(
			"user"=>array("id"=>"cxt", "name"=>"Cxt"),
			"menu"=>array(
				"children"=>array(
					array("text"=>"Cxt Demo", "leaf"=>true, "view"=>"Cxt.demo.Demo", "iconCls"=>"icon-check"),
					array("text"=>"文件", "children"=>array(
						array("text"=>"新建","leaf"=>true, "iconCls"=>"icon-add", "view"=>"Cxt.demo.view.New"),
						array("text"=>"打开","leaf"=>true, "iconCls"=>"icon-open", "view"=>"Cxt.demo.view.Open")
					))
				)
			)
		)
	);
	echo json_encode($data);
} else {
	echo "{success: false}";
}
?>
