Ext.define('Cxt.demo.widgets.Demo', {
	extend : 'Ext.panel.Panel',
	layout : 'border',
	height : '100%',
	border : 0,
	title : 'Widgets Demo',
	initComponent : function() {
		var me = this;
		var demoStore = Ext.create('Ext.data.Store', {
					fields : ['name', 'className'],
					data : [{
								name : 'CodeNameField',
								className : 'Cxt.demo.widgets.CodeNameField'
							}, {
								name : 'CrudToolbar',
								className : 'Cxt.demo.widgets.CrudToolbar'
							}, {
								name : 'CTextField',
								className : 'Cxt.demo.widgets.CTextField'
							}, {
								name : 'HtmlLayout',
								className : 'Cxt.demo.widgets.HtmlLayout'
							}, {
								name : 'Region',
								className : 'Cxt.demo.widgets.Region'
							}]
				});
		me.dirView = Ext.create('Ext.grid.Panel', {
					store : demoStore,
					title : 'Content',
					columns : [{
								xtype : 'rownumberer'
							}, {
								dataIndex : 'name',
								width : '100%'
							}],
					hideHeaders : true,
					region : 'west',
					width : 200
				});
		me.contentView = Ext.create('Ext.panel.Panel', {
					region : 'center',
					bodyPadding : 10,
					layout : 'fit'
				});
		me.layout = 'border';
		me.items = [me.dirView, me.contentView];
		me.callParent();

		me.dirView.getSelectionModel()
				.on('selectionchange', me.showContent, me);
	},

	showContent : function(sm, recs) {
		var me = this;
		me.contentView.removeAll();
		var rec = recs[0];
		var className = rec.get('className');

		var mask = new Ext.LoadMask(me, {
					msg : 'Loading...'
				});
		mask.show();
		Ext.Ajax.request({
			url : Ext.Loader.getPath(className),
			success : function(rsp) {
				mask.hide();
				var inst = Ext.create(className, {
							title : rec.get('name'),
							region : 'north'
						});
				var src = Ext.create('Ext.panel.Panel', {
							title : 'Source',
							region : 'center',
							style : {
								'margin-top' : '10px'
							},
							bodyPadding : 10,
							autoScroll : true,
							html : '<pre style="font-size:12;font-family:courier new">'
									+ Ext.String.htmlEncode(rsp.responseText
											.replace(/\t/g, '  ')) + '</pre>'
						});
				var view = Ext.create('Ext.panel.Panel', {
							layout : 'border',
							framed : false,
							border : 0,
							bodyStyle : {
								'background-color' : 'white'
							},
							items : [inst, src]
						});
				me.contentView.add(view);
			}
		});
	}
});
