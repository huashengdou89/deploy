<?php
function utfdecode($url)

{
   preg_match_all('/%u([[:alnum:]]{4})/', $url, $a);
   foreach ($a[1] as $uniord)
   {
       $dec = hexdec($uniord);
       $utf = '';
       if ($dec < 128)
       {
           $utf = chr($dec);
       }
       else if ($dec < 2048)
       {
           $utf = chr(192 + (($dec - ($dec % 64)) / 64));
           $utf .= chr(128 + ($dec % 64));
       }
       else
       {
           $utf = chr(224 + (($dec - ($dec % 4096)) / 4096));
           $utf .= chr(128 + ((($dec % 4096) - ($dec % 64)) / 64));
           $utf .= chr(128 + ($dec % 64));
       }
       $url = str_replace('%u'.$uniord, $utf, $url);
   }
   return urldecode($url);
}

$sample = array(
array(id=>"3000494",code=>"010443",name=>"巨门西式5号彩色信封-DLGL01-0415/巨门"),
array(id=>"3000495",code=>"010444",name=>"巨门西式2号彩色信封-B6GL01-0413/巨门"),
array(id=>"3000507",code=>"010673",name=>"迪士尼铁笔盒（小）Z112038/海达"),
array(id=>"3000526",code=>"010894",name=>"薰衣草100MM音乐水球L10618/万风"),
array(id=>"3000527",code=>"010895",name=>"薰衣草45MM水球L10607/万风"),
array(id=>"3000529",code=>"010917",name=>"小熊家族2R方型相架右熊D12258/万风"),
array(id=>"3000534",code=>"010957",name=>"0.38米菲家族总动员圆珠笔FBP86402/晨光"),
array(id=>"3000543",code=>"010990",name=>"东亚JV0.383-ZERO中性笔(黑)/东亚"),
array(id=>"3000544",code=>"010991",name=>"东亚JV0.383-ZERO中性笔(蓝)/东亚"),
array(id=>"3000546",code=>"010993",name=>"东亚JV0.383-ZERO中性笔(红)/东亚"),
array(id=>"3000554",code=>"011001",name=>"东亚0.38IColor中性笔(黑/兰/红)31#/东亚"),
array(id=>"3000555",code=>"011003",name=>"东亚0.5U-KNOCK-XQ中性笔(蓝)/东亚"),
array(id=>"3000557",code=>"011008",name=>"东亚0.5U-KNOCK-XQ中性笔(红)/东亚"),
array(id=>"3000581",code=>"011099",name=>"斑马(ZEBRA)嗜喱笔0.4JJS2（黑色）/斑马"),
array(id=>"3000582",code=>"011100",name=>"斑马(ZEBRA)嗜喱笔0.4JJS2（蓝色）/斑马"),
array(id=>"3000585",code=>"011108",name=>"斑马秀丽笔(小楷)WF-1/斑马"),
array(id=>"3000591",code=>"011133",name=>"晨光0.28黑色特细记帐中性笔GP0096/晨光"),
array(id=>"3000616",code=>"011218",name=>"优酷圆珠笔（黑、兰）95808/得力"),
array(id=>"3000617",code=>"011221",name=>"优酷圆珠笔（黑、兰）95823/得力"),
array(id=>"3000653",code=>"011413",name=>"科迪能便携型计算器PA-200/龙更翔"),
array(id=>"3000656",code=>"011419",name=>"科迪能便携型计算器PA-346/龙更翔"),
array(id=>"3000670",code=>"011457",name=>"晨光HB0.7MM米菲家族铅芯FSL50002"),
array(id=>"3000671",code=>"011458",name=>"晨光HB0.5MM米菲家族铅芯FSL50003"),
array(id=>"3000672",code=>"011459",name=>"晨光0.35MM米菲中性笔芯黑色FGR65227A"),
array(id=>"3000673",code=>"011460",name=>"晨光0.35MM米菲中性笔芯蓝色FGR65227B"),
array(id=>"3000678",code=>"011466",name=>"晨光0.5MM考试必备中性笔黑色AGP10702"),
array(id=>"3000679",code=>"011467",name=>"晨光0.5MM米菲中性笔黑色FGP80205A"),
array(id=>"3000681",code=>"011469",name=>"晨光0.35MM米菲中性笔黑色FGP17506A"),
array(id=>"3000682",code=>"011470",name=>"晨光0.35MM米菲中性笔蓝色FGP17506B"),
array(id=>"3000685",code=>"011479",name=>"晨光考试必备2B涂卡+铅芯套装HAMP0064"),
array(id=>"3000687",code=>"011481",name=>"得力学生卡装规尺套装9609/得力"),
array(id=>"3000688",code=>"011482",name=>"得力298*198mm垫板9353/得力"),
array(id=>"3000691",code=>"011487",name=>"马培德2B考试套装+笔刨CH895014/斯塔"),
array(id=>"3000692",code=>"011488",name=>"马培德学子圆规（可插笔）CH119140"),
array(id=>"3000693",code=>"011489",name=>"马培德自动铅学子圆规CH119430/斯塔"),
array(id=>"3000694",code=>"011490",name=>"马培德专业技术600橡皮AA011602/斯塔"),
array(id=>"3000708",code=>"011539",name=>"酷狗五行计数器GU-023022"),
array(id=>"3000709",code=>"011540",name=>"酷狗18色彩色笔GU-053097"),
array(id=>"3000726",code=>"011747",name=>"晨光0.5mm米菲系列圆珠笔FBP87504"),
array(id=>"3000727",code=>"011748",name=>"晨光0.5mm考试必备中性笔黑色AGP63501A"),
array(id=>"3000728",code=>"011750",name=>"晨光0.5mm简单爱中性笔黑色AGP61602A"),
array(id=>"3000729",code=>"011753",name=>"晨光0.5mm黑钻中性笔黑色AGP62401A"),
array(id=>"3000737",code=>"011768",name=>"百乐Hi-TecC超细钢珠笔0.4黑BLLH20C4-B-CHN"),
array(id=>"3000743",code=>"011774",name=>"百乐P500啫喱墨走珠笔0.5黑BL-P50-B"),
array(id=>"3000752",code=>"011783",name=>"百乐新威宝笔0.5-黑BL-C.BLN-VBG5-B"),
array(id=>"3000759",code=>"011790",name=>"百乐G-3啫喱笔0.5黑BL-G3-5-B"),
array(id=>"3000762",code=>"011793",name=>"百乐新G-1啫喱笔(护手胶)0.5黑BLGP-G1-5-B"),
array(id=>"3000765",code=>"011796",name=>"百乐摩磨擦0.5黑LFB-20EF-B-CHN"),
array(id=>"3000768",code=>"011799",name=>"百乐摩磨擦笔0.5蓝LFB-20EF-L-CHN"),
array(id=>"3000772",code=>"011804",name=>"百乐摩磨擦笔0.7黑LFB-20F-B-CHN"),
array(id=>"3000782",code=>"011815",name=>"百乐G-3啫喱笔0.38黑BLN-G3-38-B"),
array(id=>"3000785",code=>"011818",name=>"百乐超级啫喱笔0.5黑BL-SG-5-B"),
array(id=>"3000808",code=>"011842",name=>"百乐80按制圆珠笔0.7蓝BPK-P-SL"),
array(id=>"3000813",code=>"011847",name=>"百乐V5威宝走珠笔黑BX-V5-B"),
array(id=>"3000830",code=>"011868",name=>"百乐0.5秀丽自动铅笔芯2BPPL-5-2B"),
array(id=>"3000831",code=>"011870",name=>"百乐0.7秀丽自动铅笔芯2BPPL-7-2B"),
array(id=>"3000839",code=>"011879",name=>"百乐G-1啫喱笔0.5黑BL-G1-5T-B"),
array(id=>"3000876",code=>"011961",name=>"和一进口原稿纸(400格)16-200/博文"),
array(id=>"3000877",code=>"011962",name=>"和一16-203进口双行信纸182/博文"),
array(id=>"3000878",code=>"011963",name=>"和一16-201进口单行信纸(红线)181/博文"),
array(id=>"3000899",code=>"011987",name=>"姚记168扑克/博文"),
array(id=>"3000907",code=>"011995",name=>"得力10#订书针0010"),
array(id=>"3000908",code=>"011996",name=>"得力12#统一订书针0012"),
array(id=>"3000909",code=>"011997",name=>"得力彩色工字钉0021"),
array(id=>"3000910",code=>"011998",name=>"得力图钉0022"),
array(id=>"3000911",code=>"011999",name=>"得力大头针0023"),
array(id=>"3000912",code=>"012000",name=>"得力彩色回形针0024"),
array(id=>"3000913",code=>"012001",name=>"得力回形针0025"),
array(id=>"3000915",code=>"012005",name=>"得力12#起订器0231"),
array(id=>"3000917",code=>"012007",name=>"得力10＃订书机0222"),
array(id=>"3000918",code=>"012009",name=>"得力12#订书机0304"),
array(id=>"3000919",code=>"012010",name=>"得力12#订书机0321"),
array(id=>"3000920",code=>"012011",name=>"得力卡装订书机组盒套装0348"),
array(id=>"3000921",code=>"012012",name=>"得力12#卡装订书机0253"),
array(id=>"3000928",code=>"012021",name=>"迷你型小屋削笔机0644"),
array(id=>"3000930",code=>"012025",name=>"得力学生胶带座818"),
array(id=>"3000933",code=>"012029",name=>"得力大号美工刀片10片/盒2011"),
array(id=>"3000936",code=>"012033",name=>"得力美工刀2031"),
array(id=>"3000937",code=>"012034",name=>"得力美工刀2053"),
array(id=>"3000944",code=>"012042",name=>"得力A5网格拉链袋5591"),
array(id=>"3000945",code=>"012043",name=>"得力B5网格拉链袋5594"),
array(id=>"3000946",code=>"012044",name=>"得力A4网格拉链袋5596"),
array(id=>"3000947",code=>"012046",name=>"得力学生剪刀6018"),
array(id=>"3000948",code=>"012047",name=>"得力学生剪刀6021"),
array(id=>"3000949",code=>"012048",name=>"得力学生剪刀6024"),
array(id=>"3000950",code=>"012049",name=>"得力学生剪刀6025"),
array(id=>"3000951",code=>"012050",name=>"得力折叠尺6224"),
array(id=>"3000952",code=>"012051",name=>"得力30CM直尺6230"),
array(id=>"3000953",code=>"012052",name=>"得力40CM直尺6240"),
array(id=>"3000954",code=>"012053",name=>"得力50CM直尺6250"),
array(id=>"3000956",code=>"012056",name=>"得力15克固体胶7162"),
array(id=>"3000957",code=>"012057",name=>"得力36克固体胶7164"),
array(id=>"3000958",code=>"012058",name=>"得力35ML液体胶水"),
array(id=>"3000962",code=>"012062",name=>"得力磁钉7835"),
array(id=>"3000963",code=>"012063",name=>"得力金属圆规8601"),
array(id=>"3000964",code=>"012065",name=>"得力带铅笔芯圆规8617"),
array(id=>"3000965",code=>"012067",name=>"得力带自动铅笔圆规8619"),
array(id=>"3000966",code=>"012068",name=>"得力带铅笔芯圆规8620"),
array(id=>"3000967",code=>"012071",name=>"得力6.5寸圆形书立9273"),
array(id=>"3000968",code=>"012072",name=>"得力8寸圆形书立9274")
);

$table = $_GET["table"];
$query = utfdecode($_GET["query"]);
$start = $_GET["start"];
if (empty($start)) $start=0;
$limit = $_GET["limit"];
if (empty($limit)) $limit=20;

echo "{success:true, data:[";
$data = array();
if (empty($query)) {
	$data = $sample;
} else {
	foreach($sample as $rec) {
		if (stripos("A".$rec["code"], $query) > 0 || stripos("A".$rec["name"], $query) > 0) { 
			array_push($data, $rec);
		}
	}
}
$result = array_slice($data,$start,$limit);
$sep="";
foreach($result as $rec) {
	echo $sep;
	$sep=",";
  echo json_encode($rec);
}
echo "],total:".count($data)."}";
?>