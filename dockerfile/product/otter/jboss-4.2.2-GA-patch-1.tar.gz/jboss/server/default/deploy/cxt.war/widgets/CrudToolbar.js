Ext.define('Cxt.widgets.CrudToolbar', {
			extend : 'Ext.toolbar.Toolbar',
			alias : 'widget.crudtoolbar',
			mixins : ['Cxt.I18n'],

			/** @cfg {boolean} backButtonVisible */

			initComponent : function() {
				var me = this, cfg = {
					items : [{
								xtype : 'button',
								itemId : 'addButton',
								text : me.itext('新增'),
								iconCls : 'icon-add',
								handler : function() {
									me.fireEvent('addPressed');
								}
							}, {
								xtype : 'button',
								itemId : 'editButton',
								text : me.itext('编辑'),
								disabled : true,
								iconCls : 'icon-edit',
								handler : function() {
									me.fireEvent('editPressed');
								}
							}, {
								xtype : 'button',
								itemId : 'saveButton',
								text : me.itext('保存'),
								disabled : true,
								iconCls : 'icon-save',
								handler : function() {
									me.fireEvent('savePressed');
								}
							}, {
								xtype : 'button',
								itemId : 'cancelButton',
								text : me.itext('取消'),
								disabled : true,
								iconCls : 'icon-cancel',
								handler : function() {
									me.fireEvent('cancelPressed');
								}
							}, {
								xtype : 'button',
								itemId : 'deleteButton',
								text : me.itext('删除'),
								disabled : true,
								iconCls : 'icon-delete',
								handler : function() {
									me.fireEvent('deletePressed');
								}
							}, {
								xtype : 'component',
								flex : 1
							}, {
								itemId : 'backButton',
								xtype : 'button',
								text : me.itext('返回'),
								hidden : me.backButtonVisible ? !me.backButtonVisible : true,
								iconCls : 'icon-back',
								handler : function() {
									me.fireEvent('backPressed');
								}
							}],

					/**
					 * @param mode
					 * @param rec
					 *            Disable editButton when mode=='view' && !rec
					 */
					enableButtons : function(mode, rec) {
						if (mode == 'view') {
							me.down('#addButton').enable();
							if (rec) {
								me.down('#editButton').enable();
								me.down('#deleteButton').enable();
							} else {
								me.down('#editButton').disable();
								me.down('#deleteButton').disable();
							}
							me.down('#saveButton').disable();
							me.down('#cancelButton').disable();
							me.down('#backButton').enable();
						} else {
							me.down('#addButton').disable();
							me.down('#editButton').disable();
							me.down('#deleteButton').disable();
							me.down('#saveButton').enable();
							me.down('#cancelButton').enable();
							me.down('#backButton').disable();
						}
					},

					setViewMode : function(rec) {
						this.enableButtons('view', rec);
					},

					setEditMode : function() {
						this.enableButtons('edit');
					},

					setReadOnlyMode : function() {
						me.down('#addButton').disable();
						me.down('#editButton').disable();
						me.down('#deleteButton').disable();
						me.down('#saveButton').disable();
						me.down('#cancelButton').disable();
						me.down('#backButton').enable();
					}
				};

				if (me.leadItems) {
					cfg.items = [].concat(me.leadItems, cfg.items);
				}
				if (me.tailItems) {
					cfg.items = [].concat(cfg.items, me.tailItems);
				}

				Ext.apply(me, cfg);
				me.callParent();
			},

			initEvents : function() {
				this.callParent();
				this.addEvents('addPressed', 'editPressed', 'savePressed',
						'cancelPressed', 'deletePressed', 'backPressed');
			}
		});