Ext.define('Cxt.widgets.DesignNote', {
			extend : 'Ext.panel.Panel',
			alias : 'widget.designnote',
			mixins : ['Cxt.I18n'],
			width : '40%',
			style : {
				padding : '0 0 0 10',
				backgroundColor : 'white'
			},
			resizable : true,
			resizeHandles : 'w',
			collapsible : true,
			initComponent : function() {
				if (!this.title)
					this.title = this.itext('注解');
				this.html = '<iframe style="width:100%;height:100%;border:0" src="'
						+ (this.appName
								? Ext.Loader.getPath(this.appName)
								: '.')
						+ '/'
						+ this.url
						+ '?_dc='
						+ new Date()
						+ '"></iframe>';
				this.callParent();
			}
		});