/**
 * 具有层次结构的选择输入框, 例如地区. svc指明的url用来获取path和children
 * <p>
 * getPath: svc?cmd=getPath&id=xxx <br>
 * return : {success:true,data:[{id,code,name,parent}}]}, 从根到此结点的路径上的结点
 * <p>
 * getChildren: svc?cmd=getChildren&id=xxx <br>
 * return : {success:true,data:[{id,code,name,parent}}]}
 */
Ext.define('Cxt.demo.widgets.Region', {
	extend : 'Ext.form.Panel',
	requires : ['Cxt.widgets.region.Field'],
	bodyPadding : 10,
	items : [{
				xtype : 'label',
				text : 'Need a php server'
			}, {
				xtype : 'regionfield',
				name : 'region',
				fieldLabel : '地区',
				labelWidth: 40,
				width : 300,
				svc : serviceUrl('Region.php')
			}, {
				xtype : 'radiogroup',
				columns : 1,
				items : [{
							name : 'fn',
							boxLabel : 'getValue()',
							inputValue : '1'
						}, {
							name : 'fn',
							boxLabel : 'getForm().getValues()',
							inputValue : '2'
						}, {
							name : 'fn',
							boxLabel : 'setValue("112") 这会调用svc?cmd=getPath&id=112',
							inputValue : '3'
						}, {
							name : 'fn',
							boxLabel : 'setValue('
									+ '{id:"anyid",code:"anycode",name:"没有这个地方",parent:"1",fullName:"中国大陆辽宁省"})'
									+ ' 这不会调用服务器, 并且不检查传入的内容是否正确',
							inputValue : '4'
						}]
			}, {
				itemId : 'call',
				xtype : 'button',
				text : 'call',
				width : 100
			}, {
				name : 'callResult',
				xtype : 'displayfield',
				value : '请选择一个功能',
				width : '100%',
				bodyPadding : 5
			}],
	initComponent : function() {
		var me = this;
		me.callParent();

		me.down('#call').handler = function() {
			var msg = me.getForm().findField("callResult");
			var fn = me.getForm().getValues()["fn"];
			var region = me.getForm().findField("region");
			if (fn == '1') {
				var v = region.getValue();
				var s = Cxt.Utils.unescapeUnicode(Ext.JSON.encode(v));
				msg.setValue(s);
			} else if (fn == '2') {
				var v = me.getForm().getValues();
				var s = Cxt.Utils.unescapeUnicode(Ext.JSON.encode(v));
				msg.setValue(s);
			} else if (fn == '3') {
				region.setValue('112');
				msg.setValue('function called');
			} else if (fn == '4') {
				region.setValue({
							id : "anyid",
							code : "anycode",
							name : "没有这个地方",
							parent : "1",
							fullName : "中国大陆辽宁省"
						});
				msg.setValue('function called');
			}
		};
	}
});
