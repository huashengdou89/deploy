Ext.define('Cxt.Utils', {
	requiress : ['Ext.window.MessageBox', 'Cxt.I18n'],
	singleton : true,
	itext : Ext.create('Cxt.I18n').itext,

	uuid : function() {
		return Ext.create('Ext.data.UuidGenerator').generate();
	},

	alert : function(title, message, config) {
		var c = {
			title : title,
			msg : message,
			icon : Ext.Msg.ERROR,
			buttons : Ext.Msg.OK
		};
		if (config)
			Ext.apply(c, config);
		Ext.Msg.show(c);
	},

	info : function(message, callback) {
		this.alert(this.itext('信息'), message, {
					icon : Ext.Msg.INFO,
					fn : callback
				});
	},

	error : function(message, callback) {
		this.alert(this.itext('错误'), message, {
					icon : Ext.Msg.ERROR,
					buttons : Ext.Msg.OK,
					fn : callback
				});
	},

	confirm : function(message, callback) {
		this.alert(this.itext('确认'), message, {
					icon : Ext.Msg.QUESTION,
					buttons : Ext.Msg.YESNO,
					fn : callback
				});
	},

	formProxyFailure : function(form, operation) {
		var error = operation.getError();
		if (error) {
			this.markInvalidValues(form, error.invalidValues);
			if (error.text) {
				this.alert(Cxt.Utils.itext('错误'), error.text);
			}
		}
	},

	markInvalidValues : function(form, invalidValues) {
		if (invalidValues && form) {
			var fields = form.getFields();
			for (i in invalidValues) {
				j = fields.findIndex('name', i);
				if (j >= 0)
					fields.getAt(j).markInvalid(invalidValues[i]);
			}
		}
	},

	replaceView : function(oldView, newView) {
		var ctnr = oldView.el.dom.parentElement;
		ctnr.removeChild(oldView.el.dom);
		newView.render(ctnr);
		Ext.EventManager.onWindowResize(function() {
					this.doLayout();
				}, newView);
		return newView;
	},

	unescapeUnicode : function(msg) {
		var r = /\\u([\d\w]{4})/gi;
		var s = msg.replace(r, function(match, grp) {
					return String.fromCharCode(parseInt(grp, 16));
				});
		return unescape(s);
	},

	ajax : function(config) {
		var mask;
		if (config.mask)
			mask = new Ext.LoadMask(config.mask.target, {
						msg : config.mask.message
					}).show();
		var request = Ext.apply({
					success : function(rsp) {
						var ret = {
							success : false
						};
						try {
							ret = Ext.JSON.decode(rsp.responseText);
						} catch (e) {
						}
						if (ret.success) {
							config.success(ret);
						} else {
							if (config.failure)
								config.failure(ret);
							else
								Cxt.Utils.error(ret.message);
						}
					},
					failure : function(rsp) {
						Cxt.Utils.error(rsp.responseText);
					},
					callback : function() {
						if (mask)
							mask.hide();
					}
				}, config.request);
		Ext.Ajax.request(request);
	},

	applicationScopeBeans : {},

	getBean : function(className) {
		var bean = this.applicationScopeBeans[className];
		if (!bean) {
			bean = Ext.create(className);
			if (bean.lifeScope == 'application')
				this.applicationScopeBeans[className] = bean;
		}
		return bean;
	},

	formatJson : function(json, options) {
		var reg = null, formatted = '', pad = 0, PADDING = '    '; // one can
		// also use
		// '\t' or a
		// different
		// number of
		// spaces

		// optional settings
		options = options || {};
		// remove newline where '{' or '[' follows ':'
		options.newlineAfterColonIfBeforeBraceOrBracket = (options.newlineAfterColonIfBeforeBraceOrBracket === true)
				? true
				: false;
		// use a space after a colon
		options.spaceAfterColon = (options.spaceAfterColon === false)
				? false
				: true;

		// begin formatting...
		if (typeof json !== 'string') {
			// make sure we start with the JSON as a string
			// json = JSON.stringify(json);
			json = Ext.JSON.encode(json);
		} else {
			// is already a string, so parse and re-stringify in order to remove
			// extra whitespace
			// json = JSON.parse(json);
			// json = JSON.stringify(json);
			json = Ext.JSON.decode(json);
			json = Ext.JSON.encode(json);
		}

		// add newline before and after curly braces
		reg = /([\{\}])/g;
		json = json.replace(reg, '\r\n$1\r\n');

		// add newline before and after square brackets
		reg = /([\[\]])/g;
		json = json.replace(reg, '\r\n$1\r\n');

		// add newline after comma
		reg = /(\,)/g;
		json = json.replace(reg, '$1\r\n');

		// remove multiple newlines
		reg = /(\r\n\r\n)/g;
		json = json.replace(reg, '\r\n');

		// remove newlines before commas
		reg = /\r\n\,/g;
		json = json.replace(reg, ',');

		// optional formatting...
		if (!options.newlineAfterColonIfBeforeBraceOrBracket) {
			reg = /\:\r\n\{/g;
			json = json.replace(reg, ':{');
			reg = /\:\r\n\[/g;
			json = json.replace(reg, ':[');
		}
		if (options.spaceAfterColon) {
			reg = /\:/g;
			json = json.replace(reg, ': ');
		}

		Ext.Array.forEach(json.split('\r\n'), function(node, index) {
					var i = 0, indent = 0, padding = '';

					if (node.match(/\{$/) || node.match(/\[$/)) {
						indent = 1;
					} else if (node.match(/\}/) || node.match(/\]/)) {
						if (pad !== 0) {
							pad -= 1;
						}
					} else {
						indent = 0;
					}

					for (i = 0; i < pad; i++) {
						padding += PADDING;
					}

					formatted += padding + node + '\r\n';
					pad += indent;
				});

		return formatted;
	},

	toFixed : function(v, p) {
		return Ext.Number.from(Ext.Number.toFixed(Ext.Number.from(v, 0), p));
	}

});
