/**
 * 提交一个作业(submit), 轮询并显示进度窗口(poll), 最终完成(finish)并清除进度窗口. 全部完成后, 调用done(). <br>
 * 
 * 提交时, 调用baseUrl/submit, 请求参数为submit(params)中的params,
 * 响应为{success:boolean,data:{jobId:string}}<br>
 * 
 * 得到jobId后, 调用baseurl/poll, 请求参数为jobId:jobId,
 * 响应为{success:boolean,data:{percent:double}}<br>
 * 
 * 当percent>=1时, 调用baseUrl/commit, 请求参数为jobId:jobId
 * 
 * 例如
 * 
 * <pre>
 * 			mImportUsers : function() {
 * 				var me = this, f = me.importUsersForm;
 * 
 * 				if (me.importUsersRunning)
 * 					return;
 * 				me.importUsersRunning = true;
 * 				f.down('#execute').disable();
 * 				
 * 				var actCode = f.getForm().getValues().actCode;
 * 				f.down('#execute').disable();
 * 				Ext.create('Cxt.SubmitPoll', {
 * 							title : '导入用户',
 * 							message : &quot;正在从&quot; + actCode + &quot;活动中导入用户...&quot;,
 * 							baseUrl : 'data/sys/user/importUsers/',
 * 							done : function() {
 * 								me.importUsersRunning = false;
 * 								f.down('#execute').enable();
 * 							}
 * 						}).submit({
 * 							actCode : actCode
 * 						});
 * 			}
 * </pre>
 */
Ext.define('Cxt.SubmitPoll', {
			jobIdProperty : 'jobId',
			percentProperty : 'percent',
			messageProperty : 'message',
			title : null, // progress window title
			message : null, // progress window message
			progressWindow : null,
			baseUrl : null,
			done : null, // 全部结束后调用这个方法

			constructor : function(cfg) {
				Ext.apply(this, cfg);
			},

			submit : function(params) {
				var me = this;
				me.progressWindow = Ext.Msg.progress(me.title, me.message);
				me.progressWindow.updateProgress(0, '0%', me.message);
				var me = this;
				Ext.Ajax.request({
							url : me.baseUrl + '/submit',
							params : params,
							success : function(rsp, opt) {
								var ret = Ext.JSON.decode(rsp.responseText);
								if (ret.success) {
									Ext.defer(me.poll, 1000, me, [
													ret.data[me.jobIdProperty],
													0]);
								} else {
									me.cleanUp(false, ret.message.text);
								}
							},
							failure : function(rsp, opt) {
								cleanUp(false, opt.getError());
							}
						});
			},

			poll : function(jobId, percent) {
				var me = this;
				var params = {};
				params[me.jobIdProperty] = jobId;
				params['percent'] = percent;
				Ext.Ajax.request({
							url : me.baseUrl + '/poll',
							params : params,
							success : function(rsp, opt) {
								var ret = Ext.JSON.decode(rsp.responseText);
								if (ret.success) {
									var percent = ret.data[me.percentProperty];
									var pmsg = new Number(percent * 100)
											.toFixed(0)
											+ '%';
									var message = ret.data[me.messageProperty];
									me.progressWindow.updateProgress(percent,
											pmsg, message);
									if (percent >= 1) {
										me.commit(jobId);
										me.cleanUp(true, message);
									} else {
										Ext.defer(me.poll, 1000, me, [jobId,
														percent]);
									}
								} else {
									me.cleanUp(false, ret.message.text);
								}
							},
							failure : function(rsp, opt) {
								me.cleauUp(false, opt.getError());
							}
						});
			},

			commit : function(jobId) {
				var me = this, params = {};
				params[me.jobIdProperty] = jobId;
				Ext.Ajax.request({
							url : me.baseUrl + '/commit',
							params : params
						});
			},

			cleanUp : function(success, msg) {
				var me = this;
				me.progressWindow.hide();
				if (success)
					Cxt.Utils.info(me.title, msg);
				else
					Cxt.Utils.alert(me.title, msg);
				if (me.done) {
					me.done();
				}
			}
		});
