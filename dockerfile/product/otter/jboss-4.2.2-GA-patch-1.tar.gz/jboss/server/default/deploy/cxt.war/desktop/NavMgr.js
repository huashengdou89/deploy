/**
 * 是否可以离开holder中的子panel: 调用子panel的beforeLeave.
 */
Ext.define('Cxt.desktop.NavMgr', {
			canLeaveChild : function(holder) {
				var item;
				var a = holder.items.items;
				if (a && a.length > 0)
					item = a[0];
				if (item && item.beforeLeave) {
					if (!item.beforeLeave())
						return false;
				}
				return true;
			},

			logEnter : function(viewClassName) {
				if (/^Cxt.desktop/.test(viewClassName))
					return;
				if (appcfg.logger && appcfg.logger.moduleEnter) {
					Ext.Ajax.request({
								url : serviceUrl(appcfg.logger.moduleEnter),
								method : 'GET',
								params : {
									page : viewClassName
								}
							});
				}
			}
		});