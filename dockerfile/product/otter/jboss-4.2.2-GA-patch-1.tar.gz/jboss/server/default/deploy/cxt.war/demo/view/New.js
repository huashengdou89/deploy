Ext.define('Cxt.demo.view.New', {
			extend : 'Ext.panel.Panel',
			title : 'New File',
			bodyPadding : 10,
			html : 'New file view'
		});