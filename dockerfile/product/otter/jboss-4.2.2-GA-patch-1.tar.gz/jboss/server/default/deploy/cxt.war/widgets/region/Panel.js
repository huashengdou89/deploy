/**
 * 用法: Ext.create('Cxt.widgets.region.Panel', {svc: 'someurl'});
 * <p>
 * svc为取得数据的url, 见下面关于svc的说明
 */
Ext.define('Cxt.widgets.region.Panel', {
			extend : 'Ext.panel.Panel',
			mixins : ['Cxt.I18n'],

			/**
			 * @cfg {string} svc 将使用这个url来获取path和children
			 *      <p>
			 *      getPath: svc?cmd=getPath&id=xxx <br>
			 *      return : {data:[{id,code,name,parent}}]}, 从根到此结点的路径上的结点
			 *      <p>
			 *      getChildren: svc?cmd=getChildren&id=xxx <br>
			 *      return : {data:[{id,code,name,parent}}]}
			 */

			initComponent : function() {
				var me = this;

				var cfg = {
					title : me.itext('选择地区'),
					width : 320,
					height : 200,
					framed : false,
					bodyPadding : 5
				};
				Ext.apply(me, cfg);

				me.childrenStore = Ext.create('Ext.data.Store', {
							fields : ['id', 'code', 'name', 'parent'],
							proxy : {
								type : 'ajax',
								reader : {
									type : 'json',
									root : 'data'
								}
							}
						});

				me.tbar = {
					itemId : 'toolbar',
					items : [{
								itemId : 'path',
								xtype : 'container',
								flex : 1,
								items : []
							}, {
								text : me.itext('确认'),
								iconCls : 'icon-check',
								handler : function() {
									me.fireEvent('select', me.getValue());
								}
							}, {
								text : me.itext('放弃'),
								iconCls : 'icon-cancel',
								handler : function() {
									me.fireEvent('abort');
								}
							}]
				};

				me.items = [{
					xtype : 'dataview',
					height : '100%',
					overflowY : 'auto',
					cls : 'region-selector',
					tpl : ['<tpl for=".">',
							' <div class="region-item" id="{id}">', '{name}',
							'</div></tpl>'],
					itemSelector : 'div.region-item',
					trackOver : true,
					overItemCls : 'region-item-over',
					store : me.childrenStore,
					listeners : {
						itemclick : function(dv, rec, item, index, e) {
							var path = [].concat(me.path || []);
							path.push(rec.data);
							me.setPath(path);
						}
					}
				}];

				me.callParent();
				me.addEvents('select', 'abort');
			},

			setRegionId : function(regionId) {
				var me = this;
				if (regionId) {
					Ext.Ajax.request({
								url : me.svc,
								method : 'GET',
								params : {
									cmd : 'getPath',
									id : regionId
								},
								success : function(rsp) {
									var ret = Ext.JSON.decode(rsp.responseText);
									me.setPath(ret.data);
								}
							});
				} else {
					me.setPath(null);
				}
			},

			setPath : function(path) {
				var me = this;
				me.path = path;

				// 显示在头上
				me.suspendLayouts();
				var display = me.getDockedComponent('toolbar').down('#path');
				display.removeAll();
				display.add({
							xtype : 'button',
							text : ' / ',
							height : 30,
							handler : function() {
								me.setPath(null);
							}
						});
				if (path) {
					for (var i = 0; i < path.length; ++i) {
						display.add({
									xtype : 'button',
									text : path[i].name,
									height : 30,
									path : path.slice(0, i + 1),
									handler : function() {
										me.setPath(this.path);
									}
								});
					}
				}
				me.resumeLayouts(true);

				// 获取下一层次的记录并显示
				var parentId = null;
				if (path && path.length > 0) {
					parentId = path[path.length - 1].id;
				}
				me.childrenStore.load({
							url : me.svc,
							method : 'GET',
							params : {
								cmd : 'getChildren',
								id : parentId
							}
						});
			},

			getValue : function() {
				var me = this;
				var ret = null;
				if (me.path && me.path.length > 0) {
					ret = me.path[me.path.length - 1];
					var fullName = '', sep = '';
					for (var i in me.path) {
						fullName += sep;
						sep = ' ';
						fullName += me.path[i].name;
					}
					ret.fullName = fullName;
				}
				return ret;
			},

			getPath : function() {
				var me = this;
				return me.path;
			},

			getFullName : function() {
				var me = this;
				return ret;
			}
		});
