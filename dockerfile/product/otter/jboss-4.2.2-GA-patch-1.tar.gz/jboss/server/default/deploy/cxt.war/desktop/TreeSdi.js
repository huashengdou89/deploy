Ext.define('Cxt.desktop.TreeSdi', {
			extend : 'Ext.container.Viewport',
			mixins : ['Cxt.I18n', 'Cxt.desktop.NavMgr'],
			requires : ['Cxt.desktop.TopBanner', 'Cxt.desktop.FootBanner'],

			initComponent : function() {
				var me = this;
				var cfg = {
					layout : 'border',
					padding : 2,
					items : [{
								region : 'north',
								xtype : 'desktoptopbanner'
							}, {
								itemId : 'menuPane',
								region : 'west',
								xtype : 'treepanel',
								collapsible : true,
								resizable : true,
								width : 200,
								rootVisible : false,
								store : Ext.create('Ext.data.TreeStore', {
											fields : ['view', 'text', 'leaf'],
											root : me
													.createTreeData(appcfg.menu)
										})
							}, {
								itemId : 'contentPane',
								region : 'center',
								xtype : 'panel',
								layout : 'fit'
							}, {
								region : 'south',
								xtype : 'desktopfootbanner'
							}]
				};
				Ext.apply(me, cfg);
				me.callParent();
				var menu = me.down('#menuPane');
				menu.expandAll();
				menu.on('itemclick', me.showView, me);
			},

			/** 去除数据中的字符串元素, 如分隔符等 */
			createTreeData : function(data) {
				var me = this;
				var ret = {};
				for (var i in data) {
					if (i == 'children') {
						ret.children = [];
						for (var j in data[i]) {
							var item = data[i][j];
							if (typeof(item) != 'string') {
								ret.children.push(me.createTreeData(item));
							}
						}
					} else {
						ret[i] = data[i];
					}
				}
				return ret;
			},

			showView : function(tree, record) {
				if (record.get('view')) {
					this.setContentPane(record.get('view'));
				}
			},

			setContentPane : function(viewClassName) {
				var me = this;
				var holder = me.down('#contentPane');
				if (!me.canLeaveChild(holder))
					return;
				var view = Ext.create(viewClassName);
				holder.removeAll();
				holder.add(view);
				me.logEnter(viewClassName);
			}
		});
