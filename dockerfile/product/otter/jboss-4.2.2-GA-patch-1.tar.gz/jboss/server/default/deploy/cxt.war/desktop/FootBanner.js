Ext.define('Cxt.desktop.FootBanner', {
			extend : 'Ext.panel.Panel',
			itemId: 'desktopFootBanner',
			alias : 'widget.desktopfootbanner',
			border : 0,
			bodyPadding : 2,
			layout : 'hbox',
			items : [{
						xtype : 'component',
						flex : 1,
						html : appcfg.desktop.footer
					}]
		});