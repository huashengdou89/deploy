Ext.define('Cxt.desktop.TopBanner', {
	extend : 'Ext.panel.Panel',
	requires : ['Cxt.desktop.Switcher'],
	mixins : ['Cxt.I18n'],
	alias : 'widget.desktoptopbanner',
	initComponent : function() {
		var me = this;

		var items = [{
					xtype : 'component',
					flex : 1,
					html : appcfg.desktop.title
				}];
		if (appcfg.user) {
			items.push({
						xtype : 'label',
						padding : 5,
						text : me.itext('当前用户: ') + appcfg.user.name
					}, {
						xtype : 'component',
						width : 10
					}, {
						xtype : 'button',
						text : me.itext('注销'),
						handler : function() {
							new Ext.LoadMask(Ext.getBody(), {
										msg : me.itext('正在注销...')
									}).show();
							Ext.Ajax.request({
										url : serviceUrl(appcfg.login.services.logout),
										callback : function() {
											location.reload();
										}
									});
						}
					}, {
						xtype : 'component',
						width : 10
					});
		}
		items.push({
					xtype : 'desktopswitcher'
				});

		var cfg = {
			itemId : 'desktopTopBanner',
			border : 0,
			bodyPadding : 2,
			layout : 'hbox',
			items : items
		};
		Ext.apply(me, cfg);
		me.callParent();
	}
});