Ext.define('Cxt.I18n', {
			itext : function(key, defaultValue) {
				return (this.i18n && this.i18n[key])
						? (this.i18n[key])
						: (defaultValue ? defaultValue : key);
			}
		});