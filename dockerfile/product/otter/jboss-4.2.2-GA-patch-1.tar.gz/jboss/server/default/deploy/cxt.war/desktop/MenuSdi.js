Ext.define('Cxt.desktop.MenuSdi', {
			extend : 'Ext.container.Viewport',
			mixins : ['Cxt.I18n', 'Cxt.desktop.NavMgr'],
			requires : ['Cxt.desktop.TopBanner', 'Cxt.desktop.FootBanner'],

			initComponent : function() {
				var cfg = {
					layout : 'border',
					padding : 2,
					items : [{
								region : 'north',
								xtype : 'desktoptopbanner',
								bbar : this.createMenu(appcfg.menu.children)
							}, {
								itemId : 'contentPane',
								region : 'center',
								xtype : 'panel',
								layout : 'fit'
							}, {
								region : 'south',
								xtype : 'desktopfootbanner'
							}]
				};
				Ext.apply(this, cfg);
				this.callParent();
			},

			createMenu : function(menudata) {
				var me = this;
				var menu = [];
				var showView = Ext.bind(me.showView, me);
				for (var i in menudata) {
					var itemdata = menudata[i];
					var item;
					if (typeof(itemdata) == 'string') {
						item = itemdata;
					} else {
						item = {
							text : itemdata.text,
							viewclass : itemdata.view,
							iconCls : itemdata.iconCls
						};

						if (itemdata.leaf && itemdata.view) {
							item.handler = showView;
						}

						if (!itemdata.leaf) {
							item.menu = this.createMenu(itemdata.children);
						}
					}
					menu.push(item);
				}
				return menu;
			},

			showView : function(menuitem) {
				if (menuitem.viewclass) {
					this.setContentPane(menuitem.viewclass);
				}
			},

			setContentPane : function(viewClassName) {
				var me = this;
				var holder = me.down('#contentPane');
				if (!me.canLeaveChild(holder))
					return;
				var view = Ext.create(viewClassName);
				holder.removeAll();
				holder.add(view);
				me.logEnter(viewClassName);
			}

		});