/**
 * 用作选择地输入地区(国家-省份-城市-区县), 或带有层次结构的数据.
 * <p>
 * 用法: {xtype:'regionfield', svc:'someurl'}
 * <p>
 * svc用来来获取path和children
 * <p>
 * getPath: svc?cmd=getPath&id=xxx <br>
 * return : {data:[{id,code,name,parent}}]}, 从根到此结点的路径上的结点
 * <p>
 * getChildren: svc?cmd=getChildren&id=xxx <br>
 * return : {data:[{id,code,name,parent}}]}
 */
Ext.define('Cxt.widgets.region.Field', {
	extend : 'Ext.form.field.Picker',
	alias : 'widget.regionfield',
	requires : ['Cxt.widgets.region.Panel'],
	minxins:['Cxt.I18n'],
	matchFieldWidth : false,
	editable : false,

	/**
	 * @cfg {string} svc 用作getPath,getChildren. 见{Cxt.widgets.region.Panel}
	 */

	createPicker : function() {
		var me = this;
		return Ext.create('Cxt.widgets.region.Panel', {
					svc : me.svc,
					title : null,
					pickerField : me,
					ownerCt : me.ownerCt,
					renderTo : document.body,
					floating : true,
					hidden : true,
					focusOnShow : true,
					listeners : {
						scope : me,
						select : me.onSelect,
						abort : me.onAbort
					}
				});
	},

	valueToRaw : function(value) {
		return value ? value.fullName : null;
	},

	rawToValue : function(raw) {
		var v = null;
		if (this.value) {
			v = raw == this.value.fullName ? this.value : null;
		}
		return v;
	},

	getSubmitValue : function() {
		return this.value ? this.value.id : null;
	},

	/**
	 * 
	 * 
	 * @param {string|object}
	 *            value 如果value是string, 表示它是regionId, 调用svc?cmd=getPath获得路径;
	 *            <br>
	 *            如果是object, 应具有{id,code,name,parent,fullName}属性.
	 * @return {}
	 */
	setValue : function(value) {
		var me = this;
		if (value && Ext.typeOf(value) == 'string') {
			me.setRawValue(me.itext('加载中...'));
			Ext.Ajax.request({
						url : me.svc + '?cmd=getPath&id=' + value,
						success : function(rsp) {
							var ret = Ext.JSON.decode(rsp.responseText);
							var path = ret.data, fullName = '', sep = '', rec, i;
							if (path && path.length > 0) {
								rec = path[path.length - 1];
								for (i in path) {
									fullName += sep;
									sep = ' ';
									fullName += path[i].name;
								}
								rec.fullName = fullName;
							}
							me.setValue(rec);
						}
					});
		} else {
			return me.callParent(arguments);
		}
	},

	onSelect : function(rec) {
		var me = this;
		me.setValue(rec);
		me.fireEvent('select', rec);
		me.collapse();
	},

	onAbort : function() {
		this.collapse();
	},

	onExpand : function() {
		this.getPicker().setRegionId(this.value ? this.value.id : null);
	},

	onCollapse : function() {
		this.focus(false, 60);
	}

});