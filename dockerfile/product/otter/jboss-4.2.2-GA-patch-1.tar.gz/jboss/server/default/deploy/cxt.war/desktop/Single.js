Ext.define('Cxt.desktop.Single', {
			extend : 'Ext.container.Viewport',
			requires : ['Cxt.desktop.TopBanner', 'Cxt.desktop.FootBanner'],

			initComponent : function() {
				var cfg = {
					layout : 'fit',
					padding : 2,
					items : [{
								itemId : 'contentPane',
								region : 'center',
								xtype : 'panel',
								layout : 'fit'
							}]
				};
				Ext.apply(this, cfg);
				this.callParent();
			},

			setContentPane : function(view) {
				var holder = this.down('#contentPane');
				holder.removeAll();
				holder.add(Ext.create(view));
			}

		});