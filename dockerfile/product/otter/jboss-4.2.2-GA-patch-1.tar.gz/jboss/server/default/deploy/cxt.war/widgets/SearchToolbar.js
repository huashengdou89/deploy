Ext.define('Cxt.widgets.SearchToolbar', {
			extend : 'Ext.toolbar.Toolbar',
			alias : 'widget.searchtoolbar',
			mixins : ['Cxt.I18n'],

			initComponent : function() {
				var me = this, cfg = {
					items : [{
								xtype : 'button',
								itemId : 'search',
								text : me.itext('查找'),
								iconCls : 'icon-search',
								handler : function() {
									me.fireEvent('searchPressed');
								}
							}, {
								xtype : 'button',
								itemId : 'cancelButton',
								text : me.itext('取消'),
								iconCls : 'icon-cancel',
								handler : function() {
									me.fireEvent('cancelPressed');
								}
							}, {
								xtype : 'component',
								flex : 1
							}, {
								xtype : 'button',
								itemId : 'resetButton',
								text : me.itext('重置'),
								iconCls : 'icon-reset',
								handler : function() {
									me.fireEvent('resetPressed');
								}
							}]
				};
				Ext.apply(me, cfg);
				me.callParent();
			},

			initEvents : function() {
				var me = this;
				me.callParent();
				me.addEvents('searchPressed', 'cancelPressed', 'resetPressed');
			}
		});