/**
 * 当焦点失去的时候, 如果文本框的内容和上次失去焦点时的不一样, 调用blurHandler
 */
Ext.define('Cxt.widgets.CTextField', {
			extend : 'Ext.form.field.Text',
			alias : 'widget.ctextfield',
			requires : ['Ext.form.field.Text'],
			setValue : function(value) {
				var me = this;
				me.callParent(arguments);
				me.lastBlurValue = value;
				return me;
			},

			setValueChanged : function() {
				me.lastBlurValue = '';
			},

			/**
			 * @cfg {function} blurHandler blur时内容和上次blur时的不一样,调用这个函数.
			 */

			initComponent : function() {
				var me = this;
				me.callParent();
				me.on('blur', function() {
							var newValue = me.getValue();
							if (!me.lastBlurValue)
								me.lastBlurValue = '';
							if (newValue != me.lastBlurValue) {
								me.lastBlurValue = newValue;
								if (me.blurHandler) {
									me.blurHandler(me);
								}
							}
						});
				me.on('specialkey', function(field, e) {
							if (e.getKey() == e.ENTER) {
								var changed = false;
								var newValue = me.getValue();
								if (!me.lastBlurValue)
									me.lastBlurValue = '';
								if (newValue != me.lastBlurValue) {
									me.lastBlurValue = newValue;
									changed = true;
								}
								if (me.enterHandler) {
									me.enterHandler(me, changed);
								}
							}
						});
			}
		});