Ext.define('Cxt.demo.view.Open', {
			extend : 'Ext.panel.Panel',
			title : 'Open File',
			bodyPadding : 10,
			html : 'Open file view'
		});