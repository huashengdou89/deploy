Ext.define('Cxt.desktop.Switcher', {
			extend : 'Ext.button.Button',
			mixins : ['Cxt.I18n'],
			alias : 'widget.desktopswitcher',
			initComponent : function() {
				var me = this;
				var cfg = {
					text : me.itext('视图'),
					menu : [{
						text : me.itext('菜单栏'),
						handler : function() {
							me.switchDesktop('appcfg.desktop.view',
									'Cxt.desktop.MenuSdi');
						}
					}, {
						text : me.itext('功能树'),
						handler : function() {
							me.switchDesktop('appcfg.desktop.view',
									'Cxt.desktop.TreeSdi');
						}
					}, {
						text : me.itext('平铺菜单'),
						handler : function() {
							me.switchDesktop('appcfg.desktop.view',
									'Cxt.desktop.TileSdi');
						}
					}, '-', {
						text : me.itext('中文'),
						handler : function() {
							me.switchDesktop('appcfg.locale', null);
						}
					}, {
						text : me.itext('English'),
						handler : function() {
							me.switchDesktop('appcfg.locale', 'en');
						}
					}, '-', {
						text : me.itext('1024x768'),
						handler : function() {
							window.resizeTo(1024, 768);
						}
					}, {
						text : me.itext('800x600'),
						handler : function() {
							window.resizeTo(800, 600);
						}
					}]
				};
				Ext.apply(me, cfg);
				this.callParent();
			},

			switchDesktop : function(key, value) {
				if (value)
					Ext.util.Cookies.set(key, value);
				else
					Ext.util.Cookies.clear(key);
				location.reload();
				return;
			}
		});