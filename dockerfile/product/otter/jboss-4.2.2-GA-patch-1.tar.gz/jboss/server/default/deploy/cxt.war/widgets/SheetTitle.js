Ext.define('Cxt.widgets.SheetTitle', {
			extend : 'Ext.panel.Panel',
			alias : 'widget.sheettitle',
			height : 40,
			bodyPadding : 5,

			initComponent : function() {
				this.html = '<span style="font-size:24px;font-weight:bold">'
						+ this.text + '</span>';
				this.callParent();
			}
		});