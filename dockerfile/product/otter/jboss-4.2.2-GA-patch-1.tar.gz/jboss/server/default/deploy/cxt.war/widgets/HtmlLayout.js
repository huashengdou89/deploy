/**
 * <pre>
 * layout: {
 *   type: 'html',
 *   url: HTML
 * }
 * 
 * 用提供的HTML进行排版. 当render一个item时, 这个item被放置在HTML中元素id为itemId的容器内. 例如
 * 
 * cxt/test/HtmlLayoutTest.js
 * Ext.define('Cxt.test.HtmlLayoutTest', {
 * 			requires : ['Cxt.widgets.HtmlLayout'],
 * 			extend : 'Ext.form.Panel',
 * 			layout : {
 * 				type : 'html',
 * 				url : 'cxt/test/HtmlLayoutTest.html'
 * 			},
 * 			title : 'abc',
 * 			autoScroll : true,
 * 			fieldDefaults : {
 * 				msgTarget : 'side',
 * 				hideLabel : true,
 * 				margin : 2
 * 			},
 * 			items : [{
 * 						itemId : 'aaa',
 * 						xtype : 'textfield',
 * 						name : 'aaa',
 * 						value : 'fieldvaluea',
 * 						fieldLabel : 'a',
 * 						maxLength : 10
 * 					}, {
 * 						itemId : 'bbb',
 * 						xtype : 'textfield',
 * 						name : 'bbb',
 * 						value : 'fieldvaluebbb',
 * 						fieldLabel : 'b',
 * 						hideLabel : true,
 * 						margin : 2
 * 					}, {
 * 						itemId : 'ccc',
 * 						xtype : 'fieldcontainer',
 * 						layout : 'hbox',
 * 						width : '100%',
 * 						items : [{
 * 									xtype : 'radio',
 * 									name : 'ccc',
 * 									boxLabel : 'yes'
 * 								}, {
 * 									xtype : 'radio',
 * 									name : 'ccc',
 * 									boxLabel : 'no'
 * 								}]
 * 					}]
 * 		});
 * 
 * cxt/test/HtmlLayoutTest.html
 * [table width='100%']
 * 	[tbody]
 * 		[tr]
 * 			[td]aaa[/td]
 * 			[td width='90%'][div id='aaa'][/div]
 * 			[/td]
 * 		[/tr]
 * 		[tr]
 * 			[td]bbb[/td]
 * 			[td][div id='bbb'][/div]
 * 			[/td]
 * 		[/tr]
 * 		[tr]
 * 			[td]ccc[/td]
 * 			[td][div id='ccc'][/div]
 * 			[/td]
 * 		[/tr]
 * 	[/tbody]
 * [/table]
 * [/pre]
 * 
 * 调用: 
 * Ext.create('Cxt.test.HtmlLayoutText', {renderTo: Ext.getBody()});
 * </pre>
 */

Ext.define('Cxt.widgets.HtmlLayout', {
			extend : 'Ext.layout.container.Container',
			alias : ['layout.html'],
			type : 'html',

			renderTpl : ['{%this.renderBody(out,values)%}',
					'<div id="{ownerId}-clearEl" class="', Ext.baseCSSPrefix,
					'clear" role="presentation"></div>'],

			/** @override Ext.layout.container.Container */
			doRenderBody : function(out, renderData) {
				Ext.Ajax.request({
							url : renderData.$layout.url,
							async : false,
							success : function(rsp) {
								renderData.$comp.html = rsp.responseText;
							}
						});
				this.renderContent(out, renderData);
			},

			/** @override Ext.layout.Layout */
			renderItem : function(item, target, position) {
				var me = this;
				if (item.itemId) {
					target = Ext.get(item.itemId);
					position = 0;
				}
				if (!item.rendered) {
					me.configureItem(item);
					item.render(target, position);
					me.afterRenderItem(item);
				}
			},

			/** @override Ext.layout.Layout */
			isValidParent : function(item, target, position) {
				return true;
			},

			calculate : function(ownerContext) {
			}
		});