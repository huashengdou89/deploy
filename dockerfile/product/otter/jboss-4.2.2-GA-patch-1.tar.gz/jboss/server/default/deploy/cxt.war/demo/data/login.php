<?php
session_start();
$_SESSION['user']=1;
echo "{success:true}";
// echo "{success:false, message:'登录信息不正确'}";
?>